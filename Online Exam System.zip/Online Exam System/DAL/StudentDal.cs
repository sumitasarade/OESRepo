﻿using DTO;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace DAL
{
    public class StudentDal
    {
        public DataTable GetAllStudentsDal()
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ToString()))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from Student", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public DataTable GetStudentByIdDal(string studentId)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from Student where Id='" + studentId + "'", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public bool UpdateStudentDal(StudentDto studentDto)
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string query = "Update Student SET Name=@Name, RollNo=@RollNo, Gender=@Gender, UserId=@UserId, ParentsName=@ParentsName  where Id=@studentId";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Name", studentDto.Name);
                cmd.Parameters.AddWithValue("@RollNo", studentDto.RollNo);
                cmd.Parameters.AddWithValue("@Gender", studentDto.Gender);
                cmd.Parameters.AddWithValue("@UserId", studentDto.UserId);
                cmd.Parameters.AddWithValue("@ParentsName", studentDto.ParentsName);
                cmd.Parameters.AddWithValue("@Id", studentDto.Id);
                int status = cmd.ExecuteNonQuery();

                if (status > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool InsertStudentDal(StudentDto studentDto)
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string query = "Insert into Student (Id, Name, RollNo, Gender, UserId, ParentsName) " +
                    "values(@Id, @Name, @RollNo, @Gender, @UserId, @ParentsName)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Name", studentDto.Name);
                cmd.Parameters.AddWithValue("@RollNo", studentDto.RollNo);
                cmd.Parameters.AddWithValue("@Gender", studentDto.Gender);
                cmd.Parameters.AddWithValue("@UserId", studentDto.UserId);
                cmd.Parameters.AddWithValue("@ParentsName", studentDto.ParentsName);

                int status = cmd.ExecuteNonQuery();

                if (status > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool DeleteStudentDal(int id)
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string query = "Update Student SET IsDeleted=1 where Id=@id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", id);
                int status = cmd.ExecuteNonQuery();

                if (status > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
    }
}

﻿using DTO;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class ExamDal
    {
        public string GetExamId()
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ToString()))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select max([ExamId_auto]) as examId from [GenerateExamId]", con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        return dr["examId"].ToString();
                    }
                }
            }
            return null;
        }

        public DataTable GetAllExamDal()
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ToString()))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from ExamTitle where IsDeleted=0", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public DataTable GetExamByIdDal(string examId)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from ExamTitle where Id='" + examId + "'", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public bool UpdateExamDal(ExamDto examDto)
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string query = "Update ExamTitle SET ExamTitle=@examTitle, ModifiedBy=@ModifiedBy, ModifiedDate=@ModifiedDate where Id=@examId";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@examTitle", examDto.ExamTitle);
                cmd.Parameters.AddWithValue("@ModifiedBy", examDto.ModifiedBy);
                cmd.Parameters.AddWithValue("@ModifiedDate", examDto.ModifiedDate);
                cmd.Parameters.AddWithValue("@examId", examDto.Id);
                int status = cmd.ExecuteNonQuery();

                if (status > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool InsertExamDal(ExamDto examDto)
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string query = "Insert into ExamTitle (Id,ExamTitle, ModifiedBy, ModifiedDate) " +
                    "values(@examId, @examTitle, @ModifiedBy, @ModifiedDate)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@examId", examDto.Id);
                cmd.Parameters.AddWithValue("@examTitle", examDto.ExamTitle);
                cmd.Parameters.AddWithValue("@ModifiedBy", examDto.ModifiedBy);
                cmd.Parameters.AddWithValue("@ModifiedDate", examDto.ModifiedDate);
                int status = cmd.ExecuteNonQuery();

                if (status > 0)
                {
                    GenerateExamId();
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool DeleteExamDal(string examId)
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string queryExam = "Update ExamTitle SET IsDeleted=1 where Id=@examId";
                SqlCommand cmdExam = new SqlCommand(queryExam, con);
                cmdExam.Parameters.AddWithValue("@examId", examId);
                int statusExam = cmdExam.ExecuteNonQuery();

                string queryExamDetails = "Update ExamDetails SET IsDeleted=1 where ExamId=@examId";
                SqlCommand cmdExamDetails = new SqlCommand(queryExamDetails, con);
                cmdExamDetails.Parameters.AddWithValue("@examId", examId);
                int statusExamDetails = cmdExamDetails.ExecuteNonQuery();

                string queryScheduleExam = "Update ScheduleExam SET IsDeleted=1 where ExamId=@examId";
                SqlCommand cmdScheduleExam = new SqlCommand(queryScheduleExam, con);
                cmdScheduleExam.Parameters.AddWithValue("@examId", examId);
                int statusScheduleExam = cmdScheduleExam.ExecuteNonQuery();

                string queryFees = "Update Fee SET IsDeleted=1 where ExamId=@examId";
                SqlCommand cmdFees = new SqlCommand(queryFees, con);
                cmdFees.Parameters.AddWithValue("@examId", examId);
                int statusFees = cmdFees.ExecuteNonQuery();

                if (statusExam > 0 && statusScheduleExam > 0 && statusFees > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public DataTable GetAllExamDetailsDal()
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ToString()))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from ExamDetails where IsDeleted=0", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public DataTable GetExamDetailsByIdDal(int examId)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from ExamDetails where Id='" + examId + "'", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public bool UpdateExamDetailsDal(ExamDetailsDto examDetailsDto)
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string query = "Update ExamDetails SET ExamId=@ExamId, ExamType=@examType , NoOfTests=@noOfTests, Description=@description, " +
                    "PassingMarks=@passingMarks , TotalMarks=@totalMarks, NoOfQuestions=@noOfQuestions, ModifiedBy=@ModifiedBy, Date=@date where Id=@Id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@ExamId", examDetailsDto.ExamId);
                cmd.Parameters.AddWithValue("@examType", examDetailsDto.ExamType);
                cmd.Parameters.AddWithValue("@noOfTests", examDetailsDto.NoOfTests);
                cmd.Parameters.AddWithValue("@description", examDetailsDto.Description);
                cmd.Parameters.AddWithValue("@passingMarks", examDetailsDto.PassingMarks);
                cmd.Parameters.AddWithValue("@totalMarks", examDetailsDto.TotalMarks);
                cmd.Parameters.AddWithValue("@noOfQuestions", examDetailsDto.NoOfQuestions);
                cmd.Parameters.AddWithValue("@date", examDetailsDto.Date);
                cmd.Parameters.AddWithValue("@ModifiedBy", examDetailsDto.ModifiedBy);
                cmd.Parameters.AddWithValue("@Id", examDetailsDto.Id);
                int status = cmd.ExecuteNonQuery();

                if (status > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool InsertExamDetailsDal(ExamDetailsDto examDetailsDto)
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string query = "Insert into ExamDetails (ExamId, ExamType, NoOfTests, Description ,PassingMarks, TotalMarks, NoOfQuestions, ModifiedBy, Date) " +
                    "values(@ExamId, @examType , @noOfTests, @description, @passingMarks , @totalMarks, @noOfQuestions, @ModifiedBy, @date)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@ExamId", examDetailsDto.ExamId);
                cmd.Parameters.AddWithValue("@examType", examDetailsDto.ExamType);
                cmd.Parameters.AddWithValue("@noOfTests", examDetailsDto.NoOfTests);
                cmd.Parameters.AddWithValue("@description", examDetailsDto.Description);
                cmd.Parameters.AddWithValue("@passingMarks", examDetailsDto.PassingMarks);
                cmd.Parameters.AddWithValue("@totalMarks", examDetailsDto.TotalMarks);
                cmd.Parameters.AddWithValue("@noOfQuestions", examDetailsDto.NoOfQuestions);
                cmd.Parameters.AddWithValue("@ModifiedBy", examDetailsDto.ModifiedBy);
                cmd.Parameters.AddWithValue("@date", examDetailsDto.Date);
                int status = cmd.ExecuteNonQuery();

                if (status > 0)
                {
                    GenerateExamId();
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool DeleteExamDetailsDal(int examDetailsId)
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string queryExam = "Update ExamDetails SET IsDeleted=1 where Id=@Id";
                SqlCommand cmdExam = new SqlCommand(queryExam, con);
                cmdExam.Parameters.AddWithValue("@Id", examDetailsId);
                int statusExam = cmdExam.ExecuteNonQuery();

                if (statusExam > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        private void GenerateExamId()
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string query = "insert into GenerateExamId values('y')";
                SqlCommand cmd = new SqlCommand(query, con);
                int status = cmd.ExecuteNonQuery();
            }
        }

        public string GetScheduleExamId()
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ToString()))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select max([ScheduleExamId_auto]) as scheduleExamId from [GenerateScheduleExamId]", con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        return dr["scheduleExamId"].ToString();
                    }
                }
            }
            return null;
        }

        public DataTable GetAllScheduleExamDal()
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ToString()))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from ScheduleExam where IsDeleted=0", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public DataTable GetScheduleExamByIdDal(string scheduleExamId)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from ScheduleExam where Id='" + scheduleExamId + "'", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public bool UpdateScheduleExamDal(ScheduleExamDto scheduleExamDto)
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string query = "Update ScheduleExam SET ExamId=@examId, Date=@date, Time=@time, Duration=@duration, ModifiedBy=@ModifiedBy where Id=@scheduleExamId";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@examId", scheduleExamDto.ExamId);
                cmd.Parameters.AddWithValue("@date", scheduleExamDto.Date);
                cmd.Parameters.AddWithValue("@time", scheduleExamDto.Time);
                cmd.Parameters.AddWithValue("@duration", scheduleExamDto.Duration);
                cmd.Parameters.AddWithValue("@ModifiedBy", scheduleExamDto.ModifiedBy);
                cmd.Parameters.AddWithValue("@scheduleExamId", scheduleExamDto.Id);
                int status = cmd.ExecuteNonQuery();

                if (status > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool InsertScheduleExamDal(ScheduleExamDto scheduleExamDto)
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string query = "Insert into ScheduleExam (Id, ExamId, Date, Time, Duration, ModifiedBy) values(@scheduleExamId, @examId, @date, @time, @duration, @ModifiedBy)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@scheduleExamId", scheduleExamDto.Id);
                cmd.Parameters.AddWithValue("@examId", scheduleExamDto.ExamId);
                cmd.Parameters.AddWithValue("@date", scheduleExamDto.Date);
                cmd.Parameters.AddWithValue("@time", scheduleExamDto.Time);
                cmd.Parameters.AddWithValue("@duration", scheduleExamDto.Duration);
                cmd.Parameters.AddWithValue("@ModifiedBy", scheduleExamDto.ModifiedBy);
                int status = cmd.ExecuteNonQuery();

                if (status > 0)
                {
                    GenerateScheduleExamId();
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool DeleteScheduleExamDal(string scheduleExamId)
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string query = "Update ScheduleExam SET IsDeleted=1 where Id=@scheduleExamId";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@scheduleExamId", scheduleExamId);
                int status = cmd.ExecuteNonQuery();

                if (status > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        private void GenerateScheduleExamId()
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string query = "insert into GenerateScheduleExamId values('y')";
                SqlCommand cmd = new SqlCommand(query, con);
                int status = cmd.ExecuteNonQuery();
            }
        }
    }
}

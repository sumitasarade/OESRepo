﻿using DTO;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class StudentResultDal
    {
        public DataTable GetAllStudentResultDal()
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ToString()))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from StudentResult where IsDeleted=0", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public DataTable GetStudentResultByIdDal(int studentResultId)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from StudentResult where Id='" + studentResultId + "'", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public bool UpdateStudentResultDal(StudentResultDto studentResultDto)
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string query = "Update StudentResult SET StudentId=@StudentId, ObtainedMarks=@ObtainedMarks, Percentage=@Percentage, Score=@Score" +
                    "Status=@Status, ExamDate=@ExamDate, ModifiedBy=@ModifiedBy , ModifiedDate=@ModifiedDate, ExamId=@ExamId where Id=@uploadQuestionId";
                SqlCommand cmd = new SqlCommand(query, con);
                //cmd.Parameters.AddWithValue("@StudentId", studentResultDto.StudentId);
                cmd.Parameters.AddWithValue("@ObtainedMarks", studentResultDto.ObtainedMarks);
                cmd.Parameters.AddWithValue("@Percentage", studentResultDto.Percentage);
                cmd.Parameters.AddWithValue("@Score", studentResultDto.Score);
                cmd.Parameters.AddWithValue("@Status", studentResultDto.Status);
                cmd.Parameters.AddWithValue("@ExamDate", studentResultDto.ExamDate);
                cmd.Parameters.AddWithValue("@ModifiedBy", studentResultDto.ModifiedBy);
                cmd.Parameters.AddWithValue("@ModifiedDate", studentResultDto.ModifiedDate);
                cmd.Parameters.AddWithValue("@ExamId", studentResultDto.ExamId);
                cmd.Parameters.AddWithValue("@Id", studentResultDto.Id);
                int status = cmd.ExecuteNonQuery();

                if (status > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool InsertStudentResultnDal(StudentResultDto studentResultDto)
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string query = "Insert into StudentResult (ObtainedMarks, Percentage, Score, Status, ExamDate, ModifiedBy, ModifiedDate, ExamId) " +
                    "values(@ObtainedMarks, @Percentage, @Score, @Status, @ExamDate, @ModifiedBy, @ModifiedDate, @ExamId)";
                SqlCommand cmd = new SqlCommand(query, con);
                //cmd.Parameters.AddWithValue("@StudentId", studentResultDto.StudentId);
                cmd.Parameters.AddWithValue("@ObtainedMarks", studentResultDto.ObtainedMarks);
                cmd.Parameters.AddWithValue("@Percentage", studentResultDto.Percentage);
                cmd.Parameters.AddWithValue("@Score", studentResultDto.Score);
                cmd.Parameters.AddWithValue("@Status", studentResultDto.Status);
                cmd.Parameters.AddWithValue("@ExamDate", studentResultDto.ExamDate);
                cmd.Parameters.AddWithValue("@ModifiedBy", studentResultDto.ModifiedBy);
                cmd.Parameters.AddWithValue("@ModifiedDate", studentResultDto.ModifiedDate);
                cmd.Parameters.AddWithValue("@ExamId", studentResultDto.ExamId);

                int status = cmd.ExecuteNonQuery();

                if (status > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool DeleteStudentResultDal(int studentResultId)
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string query = "Update StudentResult SET IsDeleted=1 where Id=@studentResultId";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@studentResultId", studentResultId);
                int status = cmd.ExecuteNonQuery();

                if (status >= 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

    }
}

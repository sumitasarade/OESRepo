﻿using DTO;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace DAL
{
    public class AnswerGivenDal
    {
        public DataTable GetAllAnswersDal()
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ToString()))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from AnswerGiven", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public DataTable GetAnswerByIdDal(string answerId)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from AnswerGiven where Id='" + answerId + "'", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public bool UpdateAnswerDal(AnswerGivenDto answerDto)
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string query = "Update AnswerGiven SET UserId=@UserId, QuestionId=@QuestionId," +
                    " AnswerGivenByStudent=@AnswerGivenByStudent, IsCorrect=@IsCorrect, ExamDate=@ExamDate, ExamTime=@ExamTime where Id=@answerId";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@UserId", answerDto.UserId);
                cmd.Parameters.AddWithValue("@QuestionId", answerDto.QuestionId);
                cmd.Parameters.AddWithValue("@AnswerGivenByStudent", answerDto.AnswerGivenByStudent);
                cmd.Parameters.AddWithValue("@IsCorrect", answerDto.IsCorrect);
                cmd.Parameters.AddWithValue("@ExamDate", answerDto.ExamDate);
                cmd.Parameters.AddWithValue("@ExamDate", answerDto.ExamDate);
                cmd.Parameters.AddWithValue("@answerId", answerDto.Id);
                int status = cmd.ExecuteNonQuery();

                if (status > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool InsertAnswerDal(AnswerGivenDto answerDto)
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string query = "Insert into AnswerGiven (UserId, QuestionId, AnswerGivenByStudent, IsCorrect, ExamDate, ExamTime) " +
                    "values(@UserId, @QuestionId, @AnswerGivenByStudent, @IsCorrect, @ExamDate, @ExamTime)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@UserId", answerDto.UserId);
                cmd.Parameters.AddWithValue("@QuestionId", answerDto.QuestionId);
                if(answerDto.AnswerGivenByStudent!=null)
                {
                    cmd.Parameters.AddWithValue("@AnswerGivenByStudent", answerDto.AnswerGivenByStudent);
                }
                else
                {
                    cmd.Parameters.AddWithValue("@AnswerGivenByStudent", SqlInt32.Null);
                }                
                cmd.Parameters.AddWithValue("@IsCorrect", answerDto.IsCorrect);
                cmd.Parameters.AddWithValue("@ExamDate", answerDto.ExamDate);
                cmd.Parameters.AddWithValue("@ExamTime", answerDto.ExamTime);
                int status = cmd.ExecuteNonQuery();

                if (status > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool DeleteAnswerGivenDal(int id)
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string query = "Update AnswerGiven SET IsDeleted=1 where Id=@id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", id);
                int status = cmd.ExecuteNonQuery();

                if (status > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
    }
}

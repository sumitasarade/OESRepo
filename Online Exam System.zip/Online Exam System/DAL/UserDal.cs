﻿using DTO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DAL
{
    public class UserDal
    {
        public DataTable GetAllUserDal()
        {
            DataTable dt = new DataTable();
            //List<UsersDto> feesDtos = new List<UsersDto>();           
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ToString()))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from UserDetails", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public DataTable GetUserByIdDal(int userId)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from UserDetails where Id='" + userId + "'", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public bool UpdateUserDal(UserDto userDto)
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string query = "Update UserDetails SET UserName=@UserName, Password=@Password, MobileNo=@MobileNo, Email=@Email ,RoleId=@RoleId where Id=@Id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@UserName", userDto.UserName);
                cmd.Parameters.AddWithValue("@Password", userDto.Password);
                cmd.Parameters.AddWithValue("@MobileNo", userDto.MobileNo);
                cmd.Parameters.AddWithValue("@Email", userDto.Email);
                cmd.Parameters.AddWithValue("@RoleId", userDto.RoleId);
                cmd.Parameters.AddWithValue("@Id", userDto.Id);
                int status = cmd.ExecuteNonQuery();

                if (status > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool InsertUserDal(UserDto userDto)
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();                
                string query = "Insert into UserDetails (UserName, Password, Email, MobileNo, RoleId) values(@UserName,@Password, @Email, @MobileNo, @RoleId)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@UserName", userDto.UserName);
                cmd.Parameters.AddWithValue("@Password", userDto.Password);
                cmd.Parameters.AddWithValue("@MobileNo", userDto.MobileNo);
                cmd.Parameters.AddWithValue("@Email", userDto.Email);
                cmd.Parameters.AddWithValue("@RoleId", userDto.RoleId);

                int status = cmd.ExecuteNonQuery();

                if (status > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool DeleteUserDal(int userId)
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string query = "Update UserDetails SET IsDeleted=1 where Id=@userId";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@userId", userId);
                int status = cmd.ExecuteNonQuery();

                if (status >= 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public DataTable GetAllRoleDal()
        {
            DataTable dt = new DataTable();          
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ToString()))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from Role", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }
    }
}

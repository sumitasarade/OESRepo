﻿using DTO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DAL
{
    public class UploadQuestionDal
    {
        public DataTable GetAllUploadedQuestionDal()
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ToString()))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from UploadQuestion where IsDeleted=0", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public DataTable GetUploadedQuestionByIdDal(string uploadQuestionId)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from UploadQuestion where Id='" + uploadQuestionId + "'", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public bool UpdateUploadedQuestionDal(UploadQuestionDto uploadQuestionDto)
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string query = "Update UploadQuestion SET ExamId=@examId, Question=@question, Option1=@option1, Option2=@option2, Option3=@option3, " +
                    "Option4=@option4, CorrectAnswer=@correctAnswer, Date=@date, ModifiedBy=@ModifiedBy where Id=@uploadQuestionId";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@examId", uploadQuestionDto.ExamId);
                cmd.Parameters.AddWithValue("@question", uploadQuestionDto.Question);
                cmd.Parameters.AddWithValue("@option1", uploadQuestionDto.Option1);
                cmd.Parameters.AddWithValue("@option2", uploadQuestionDto.Option2);
                cmd.Parameters.AddWithValue("@option3", uploadQuestionDto.Option3);
                cmd.Parameters.AddWithValue("@option4", uploadQuestionDto.Option4);
                cmd.Parameters.AddWithValue("@correctAnswer", uploadQuestionDto.CorrectAnswer);
                cmd.Parameters.AddWithValue("@date", uploadQuestionDto.Date);
                cmd.Parameters.AddWithValue("@ModifiedBy", uploadQuestionDto.ModifiedBy);
                cmd.Parameters.AddWithValue("@uploadQuestionId", uploadQuestionDto.Id);
                int status = cmd.ExecuteNonQuery();

                if (status > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool InsertUploadedQuestionDal(UploadQuestionDto uploadQuestionDto)
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string query = "Insert into UploadQuestion (ExamId, Question, Option1, Option2, Option3, Option4, CorrectAnswer, Date, ModifiedBy) " +
                    "values(@examId,@question, @option1, @option2,@option3,@option4,@correctAnswer,@date,@ModifiedBy)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@examId", uploadQuestionDto.ExamId);
                cmd.Parameters.AddWithValue("@question", uploadQuestionDto.Question);
                cmd.Parameters.AddWithValue("@option1", uploadQuestionDto.Option1);
                cmd.Parameters.AddWithValue("@option2", uploadQuestionDto.Option2);
                cmd.Parameters.AddWithValue("@option3", uploadQuestionDto.Option3);
                cmd.Parameters.AddWithValue("@option4", uploadQuestionDto.Option4);
                cmd.Parameters.AddWithValue("@correctAnswer", uploadQuestionDto.CorrectAnswer);
                cmd.Parameters.AddWithValue("@date", uploadQuestionDto.Date);
                cmd.Parameters.AddWithValue("@ModifiedBy", uploadQuestionDto.ModifiedBy);

                int status = cmd.ExecuteNonQuery();

                if (status > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool DeleteUploadedQuestionDal(string uploadQuestionId)
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string query = "Update UploadQuestion SET IsDeleted=1 where Id=@uploadQuestionId";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@uploadQuestionId", uploadQuestionId);
                int status = cmd.ExecuteNonQuery();

                if (status >= 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

    }
}

﻿using DTO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System;

namespace DAL
{
    public class FeesDal
    {
        //public string connectionString = @"Data Source=SUMITA\SQLEXPRESS;Initial Catalog=OESDB;Integrated Security=True";
        //public string connectionString = @"Data Source=DESKTOP-GSA90J6\SQLEXPRESS;Initial Catalog=OESDB;Integrated Security=True";

        public string GetFeeId()
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ToString()))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select max([feeid_auto]) as feeid from [GenerateFeeId]", con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        return dr["feeid"].ToString();
                    }
                }
            }
            return null;
        }

        public DataTable GetAllFeesDal()
        {
            DataTable dt = new DataTable();
            //List<FeesDto> feesDtos = new List<FeesDto>();           
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ToString()))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from Fee where IsDeleted=0", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public DataTable GetFeesByIdDal(string feeId)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from Fee where Id='" + feeId + "'", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public bool UpdateFeesDal(FeesDto feesDto)
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string query = "Update Fee SET ExamId=@examId, Amount=@amount, Date=@date, ModifiedBy=@ModifiedBy where Id=@feeId";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@examId", feesDto.ExamId);
                cmd.Parameters.AddWithValue("@amount", feesDto.Amount);
                cmd.Parameters.AddWithValue("@date", feesDto.Date);
                cmd.Parameters.AddWithValue("@ModifiedBy", feesDto.ModifiedBy);
                cmd.Parameters.AddWithValue("@feeId", feesDto.Id);
                int status = cmd.ExecuteNonQuery();

                if (status > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool InsertFeesDal(FeesDto feesDto)
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string query = "Insert into Fee (Id, ExamId, Amount,Date,ModifiedBy) values(@feeId,@examId, @amount,@date,@ModifiedBy)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@feeId", feesDto.Id);
                cmd.Parameters.AddWithValue("@examId", feesDto.ExamId);
                cmd.Parameters.AddWithValue("@amount", feesDto.Amount);
                cmd.Parameters.AddWithValue("@date", feesDto.Date);
                cmd.Parameters.AddWithValue("@ModifiedBy", feesDto.ModifiedBy);
                int status = cmd.ExecuteNonQuery();

                if (status > 0)
                {
                    GenerateFeeId();
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool DeleteFeesDal(string feeId)
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string query = "Update Fee SET IsDeleted=1 where Id=@feeId";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@feeId", feeId);
                int status = cmd.ExecuteNonQuery();

                if (status >= 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        private void GenerateFeeId()
        {
            using (SqlConnection con = new SqlConnection((ConfigurationManager.ConnectionStrings["constr"].ToString())))
            {
                con.Open();
                string query = "insert into GenerateFeeId values('y')";
                SqlCommand cmd = new SqlCommand(query, con);
                int status = cmd.ExecuteNonQuery();
            }
        }
    }
}

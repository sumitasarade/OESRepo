﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class StudentDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int RollNo { get; set; }
        public string ParentsName { get; set; }
        public int Gender { get; set; }
        public int UserId { get; set; }
    }
}

﻿namespace DTO
{
    public class ScheduleExamDto
    {
        public string Id { get; set; }
        public string ExamId { get; set; }
        public string Date { get; set; }
        public string Time { get; set; }
        public decimal Duration { get; set; }
        public int ModifiedBy { get; set; }
        public string ModifiedDate { get; set; }
    }
}

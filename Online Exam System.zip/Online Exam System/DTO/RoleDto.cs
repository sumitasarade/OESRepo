﻿namespace DTO
{
    public class RoleDto
    {
        public int Id { get; set; }
        public string RoleTitle { get; set; }
    }
}

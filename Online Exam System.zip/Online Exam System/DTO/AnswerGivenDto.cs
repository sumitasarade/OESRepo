﻿namespace DTO
{
    public class AnswerGivenDto
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int QuestionId { get; set; }
        public string AnswerGivenByStudent { get; set; }
        public int IsCorrect { get; set; }
        public string ExamDate { get; set; }
        public string ExamTime { get; set; }
    }
}

﻿namespace DTO
{
    public class StudentResultDto
    {
        public int Id { get; set; }
        public string ExamId { get; set; }
        public int ObtainedMarks { get; set; }
        public double Percentage { get; set; }
        public int Score { get; set; }
        public bool Status { get; set; }
        public string ExamDate { get; set; }
        public int ModifiedBy { get; set; }
        public string ModifiedDate { get; set; }
    }
}

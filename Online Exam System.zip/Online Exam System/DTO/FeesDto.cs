﻿namespace DTO
{
    public class FeesDto
    {
        public string Id { get; set; }
        public string ExamId { get; set; }
        public int Amount { get; set; }
        public string Date { get; set; }
        public int ModifiedBy { get; set; }
    }
}


﻿namespace DTO
{
    public class ExamDto
    {
        public string Id { get; set; }
        public string ExamTitle { get; set; }
        public int ModifiedBy { get; set; }
        public string ModifiedDate { get; set; }
        public bool IsDeleted { get; set; }
    }
}

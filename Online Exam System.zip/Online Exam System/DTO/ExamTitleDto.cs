﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class ExamTitleDto
    {
        public int Id { get; set; }
        public string Exam { get; set; }
        public string ExamType { get; set; }
        public int NoOfQuestion { get; set; }
        public int PassingMarks { get; set; }
        public int TotalMarks { get; set; }
        public string Description { get; set; }
    }
}

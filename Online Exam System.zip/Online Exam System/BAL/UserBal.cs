﻿using DAL;
using System;
using System.Collections.Generic;
using System.Data;
using DTO;
using System.Linq;

namespace BAL
{
    public class UserBal
    {
        public List<UserDto> GetAllUserBal()
        {
            UserDal userDal = new UserDal();
            DataTable user = userDal.GetAllUserDal();
            List<UserDto> userDtos = new List<UserDto>();
            for (int i = 0; i < user.Rows.Count; i++)
            {
                UserDto userDto = new UserDto();
                userDto.Id = Convert.ToInt32(user.Rows[i]["Id"]);
                userDto.UserName = user.Rows[i]["UserName"].ToString();
                userDto.Password = user.Rows[i]["Password"].ToString();
                userDto.MobileNo = user.Rows[i]["MobileNo"].ToString();
                userDto.Email = user.Rows[i]["Email"].ToString();
                userDto.RoleId = Convert.ToInt32(user.Rows[i]["RoleId"]);
                userDtos.Add(userDto);
            }
            return userDtos;
        }

        public UserDto GetUserByIdBal(int userId)
        {
            UserDal userDal = new UserDal();
            DataTable user = userDal.GetUserByIdDal(userId);
            UserDto userDto = new UserDto();
            userDto.Id = Convert.ToInt32(user.Rows[0]["Id"]);
            userDto.UserName = user.Rows[0]["UserName"].ToString();
            userDto.Password = user.Rows[0]["Password"].ToString();
            userDto.MobileNo = user.Rows[0]["MobileNo"].ToString();
            userDto.RoleId = Convert.ToInt32(user.Rows[0]["RoleId"]);
            userDto.Email = user.Rows[0]["Email"].ToString();

            return userDto;
        }

        public bool UpdateUserBal(UserDto userDto)
        {
            UserDal userDal = new UserDal();
            bool status = userDal.UpdateUserDal(userDto);
            return status;
        }

        public bool InsertUserBal(UserDto userDto)
        {
            UserDal userDal = new UserDal();
            bool status = userDal.InsertUserDal(userDto);
            return status;
        }

        public bool DeleteUserBal(int userId)
        {
            UserDal userDal = new UserDal();
            bool status = userDal.DeleteUserDal(userId);
            return status;
        }

        public int GetIdByName(string userName)
        {
            return GetAllUserBal().SingleOrDefault(x => x.UserName == userName).Id;
        }

        public bool CheckUserNameExists(string userName)
        {
            return this.GetAllUserBal().Any(x => x.UserName == userName);
        }

        public bool ValidateUser(string userName,string password)
        {
            var userResult= this.GetAllUserBal().SingleOrDefault(x => x.UserName == userName & x.Password== password);          
            if (userResult != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public int GetRoleByUserName(string userName)
        {
            return GetAllUserBal().SingleOrDefault(x => x.UserName == userName).RoleId;
        }

        public List<RoleDto> GetAllRoleBal()
        {
            UserDal userDal = new UserDal();
            DataTable role = userDal.GetAllRoleDal();
            List<RoleDto> roleDtos = new List<RoleDto>();
            for (int i = 0; i < role.Rows.Count; i++)
            {
                RoleDto roleDto = new RoleDto();
                roleDto.Id = Convert.ToInt32(role.Rows[i]["Id"]);
                roleDto.RoleTitle = role.Rows[i]["Role"].ToString();
                roleDtos.Add(roleDto);
            }
            return roleDtos;
        }

        public List<UserDto> GetUsersByRoleBal(int roleId)
        {
            return GetAllUserBal().Where(x => x.RoleId == roleId).ToList();
        }
    }
}

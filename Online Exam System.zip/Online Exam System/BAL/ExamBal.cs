﻿using DAL;
using DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace BAL
{
    public class ExamBal
    {
        public string GetExamId()
        {
            ExamDal examDal = new ExamDal();
            return "E" + examDal.GetExamId();
        }

        public List<ExamDto> GetAllExamsBal()
        {
            ExamDal examDal = new ExamDal();
            DataTable exam = examDal.GetAllExamDal();
            List<ExamDto> examDtos = new List<ExamDto>();
            for (int i = 0; i < exam.Rows.Count; i++)
            {
                ExamDto examDto = new ExamDto();
                examDto.Id = exam.Rows[i]["Id"].ToString();
                examDto.ExamTitle = exam.Rows[i]["ExamTitle"].ToString();
                examDto.ModifiedBy = Convert.ToInt32(exam.Rows[i]["ModifiedBy"]);
                examDto.ModifiedDate = exam.Rows[i]["ModifiedDate"].ToString();

                examDtos.Add(examDto);
            }
            return examDtos;
        }

        public ExamDto GetExamByIdBal(string examId)
        {
            ExamDal examDal = new ExamDal();
            DataTable exam = examDal.GetExamByIdDal(examId);

            ExamDto examDto = new ExamDto();
            examDto.Id = exam.Rows[0]["Id"].ToString();
            examDto.ExamTitle = exam.Rows[0]["ExamTitle"].ToString();
            examDto.ModifiedBy = Convert.ToInt32(exam.Rows[0]["ModifiedBy"]);
            examDto.ModifiedDate = exam.Rows[0]["ModifiedDate"].ToString();
            return examDto;
        }

        public bool UpdateExamBal(ExamDto examDto)
        {
            ExamDal examDal = new ExamDal();
            bool status = examDal.UpdateExamDal(examDto);
            return status;
        }

        public bool InsertExamBal(ExamDto examDto)
        {
            ExamDal examDal = new ExamDal();
            bool status = examDal.InsertExamDal(examDto);
            return status;
        }

        public bool DeleteExamBal(string examId)
        {
            ExamDal examDal = new ExamDal();
            bool status = examDal.DeleteExamDal(examId);
            return status;
        }

        public List<ExamDetailsDto> GetAllExamDetailsBal()
        {
            ExamDal examDal = new ExamDal();
            DataTable exam = examDal.GetAllExamDetailsDal();
            List<ExamDetailsDto> examDetailsDtos = new List<ExamDetailsDto>();
            for (int i = 0; i < exam.Rows.Count; i++)
            {
                ExamDetailsDto examDetailsDto = new ExamDetailsDto();
                examDetailsDto.Id = Convert.ToInt32(exam.Rows[i]["Id"]);
                examDetailsDto.ExamId = exam.Rows[i]["ExamId"].ToString();
                examDetailsDto.ExamType = exam.Rows[i]["ExamType"].ToString();
                examDetailsDto.NoOfTests = Convert.ToInt32(exam.Rows[i]["NoOfTests"]);
                examDetailsDto.Description = exam.Rows[i]["Description"].ToString();
                examDetailsDto.PassingMarks = Convert.ToInt32(exam.Rows[i]["PassingMarks"]);
                examDetailsDto.TotalMarks = Convert.ToInt32(exam.Rows[i]["TotalMarks"]);
                examDetailsDto.NoOfQuestions = Convert.ToInt32(exam.Rows[i]["NoOfQuestions"]);
                examDetailsDto.Date = exam.Rows[i]["Date"].ToString();
                examDetailsDto.ModifiedBy = Convert.ToInt32(exam.Rows[i]["ModifiedBy"]);

                examDetailsDtos.Add(examDetailsDto);
            }
            return examDetailsDtos;
        }

        public ExamDetailsDto GetExamDetailsByIdBal(int examDetailsId)
        {
            ExamDal examDal = new ExamDal();
            DataTable exam = examDal.GetExamDetailsByIdDal(examDetailsId);

            ExamDetailsDto examDetailsDto = new ExamDetailsDto();
            examDetailsDto.Id = Convert.ToInt32(exam.Rows[0]["Id"]);
            examDetailsDto.ExamId = exam.Rows[0]["ExamId"].ToString();
            examDetailsDto.ExamType = exam.Rows[0]["ExamType"].ToString();
            examDetailsDto.NoOfTests = Convert.ToInt32(exam.Rows[0]["NoOfTests"]);
            examDetailsDto.Description = exam.Rows[0]["Description"].ToString();
            examDetailsDto.PassingMarks = Convert.ToInt32(exam.Rows[0]["PassingMarks"]);
            examDetailsDto.TotalMarks = Convert.ToInt32(exam.Rows[0]["TotalMarks"]);
            examDetailsDto.NoOfQuestions = Convert.ToInt32(exam.Rows[0]["NoOfQuestions"]);
            examDetailsDto.Date = exam.Rows[0]["Date"].ToString();
            examDetailsDto.ModifiedBy = Convert.ToInt32(exam.Rows[0]["ModifiedBy"]);
            return examDetailsDto;
        }

        public bool UpdateExamDetailsBal(ExamDetailsDto examDetailsDto)
        {
            ExamDal examDal = new ExamDal();
            bool status = examDal.UpdateExamDetailsDal(examDetailsDto);
            return status;
        }

        public bool InsertExamDetailsBal(ExamDetailsDto examDetailsDto)
        {
            ExamDal examDal = new ExamDal();
            bool status = examDal.InsertExamDetailsDal(examDetailsDto);
            return status;
        }

        public bool DeleteExamDetailsBal(int examId)
        {
            ExamDal examDal = new ExamDal();
            bool status = examDal.DeleteExamDetailsDal(examId);

            return status;
        }

        public bool CheckExamTitleExists(string examTitle)
        {
            return GetAllExamsBal().Any(u => u.ExamTitle == examTitle && u.IsDeleted == true);
        }

        public string GetScheduleExamId()
        {
            ExamDal examDal = new ExamDal();
            return "SE" + examDal.GetScheduleExamId();
        }

        public List<ScheduleExamDto> GetAllScheduleExamsBal()
        {
            ExamDal scheduleExamDal = new ExamDal();
            DataTable scheduleExam = scheduleExamDal.GetAllScheduleExamDal();
            List<ScheduleExamDto> scheduleExamDtos = new List<ScheduleExamDto>();
            for (int i = 0; i < scheduleExam.Rows.Count; i++)
            {
                ScheduleExamDto scheduleExamDto = new ScheduleExamDto();
                scheduleExamDto.Id = scheduleExam.Rows[i]["Id"].ToString();
                scheduleExamDto.ExamId = scheduleExam.Rows[i]["ExamId"].ToString();
                scheduleExamDto.Date = scheduleExam.Rows[i]["Date"].ToString();
                scheduleExamDto.Time = scheduleExam.Rows[i]["Time"].ToString();
                scheduleExamDto.Duration = Convert.ToDecimal(scheduleExam.Rows[i]["Duration"]);
                scheduleExamDto.ModifiedBy = Convert.ToInt32(scheduleExam.Rows[i]["ModifiedBy"]);

                scheduleExamDtos.Add(scheduleExamDto);
            }
            return scheduleExamDtos;
        }

        public ScheduleExamDto GetScheduleExamByIdBal(string examScheduleId)
        {
            ExamDal examDal = new ExamDal();
            DataTable scheduleExam = examDal.GetScheduleExamByIdDal(examScheduleId);
            ScheduleExamDto scheduleExamDto = new ScheduleExamDto();

            scheduleExamDto.Id = scheduleExam.Rows[0]["Id"].ToString();
            scheduleExamDto.ExamId = scheduleExam.Rows[0]["ExamId"].ToString();
            scheduleExamDto.Date = scheduleExam.Rows[0]["Date"].ToString();
            scheduleExamDto.Time = scheduleExam.Rows[0]["TotalMarks"].ToString();
            scheduleExamDto.Duration = Convert.ToDecimal(scheduleExam.Rows[0]["Duration"]);
            scheduleExamDto.ModifiedBy = Convert.ToInt32(scheduleExam.Rows[0]["ModifiedBy"]);

            return scheduleExamDto;
        }

        public bool UpdateScheduleExamBal(ScheduleExamDto scheduleExamDto)
        {
            ExamDal examDal = new ExamDal();
            bool status = examDal.UpdateScheduleExamDal(scheduleExamDto);
            return status;
        }

        public bool InsertScheduleExamBal(ScheduleExamDto scheduleExamDto)
        {
            ExamDal examDal = new ExamDal();
            scheduleExamDto.Id = GetScheduleExamId();
            bool status = examDal.InsertScheduleExamDal(scheduleExamDto);
            return status;
        }

        public bool DeleteScheduleExamBal(string scheduleExamId)
        {
            ExamDal examDal = new ExamDal();
            bool status = examDal.DeleteScheduleExamDal(scheduleExamId);
            return status;
        }

        public IEnumerable<SelectListItem> GetExamTitleList()
        {
            var examDtos = this.GetAllExamsBal();
            return examDtos.Select(e => new SelectListItem
            {
                Value = e.Id.ToString(),
                Text = e.ExamTitle
            });
        }

        //public IEnumerable<SelectListItem> GetExamTitleListForExamDetails()
        //{
        //    List<ExamDto> examDtos = new List<ExamDto>();
        //    List<string> examIds = GetAllExamDetailsBal().Select(x => x.ExamId).ToList();
        //    foreach (string examId in examIds)
        //    {
        //        ExamDto examDto = new ExamDto();
        //        var examDt= GetAllExamsBal().Remove(examDto);
        //    }

        //    return examDtos.Select(e => new SelectListItem
        //    {
        //        Value = e.Id.ToString(),
        //        Text = e.ExamTitle
        //    });
        //}

        public IEnumerable<SelectListItem> GetExamTitleByStudentList()
        {
            var examDtos = this.GetAllExamsBal();
            return examDtos.Select(e => new SelectListItem
            {
                Value = e.Id.ToString(),
                Text = e.ExamTitle
            });
        }

        public IEnumerable<SelectListItem> GetExamTitleList1()
        {
            var examDtos = this.GetAllExamsBal();
            List<string> examIds = new List<string>();
            foreach (var item in examDtos)
            {
                if (CheckExamIdExistsInExamDetails(item.Id) == false)
                {
                    examIds.Add(item.Id);
                }
                else
                {
                    continue;
                }
            }
            return examDtos.Select(e => new SelectListItem
            {
                Value = e.Id.ToString(),
                Text = e.ExamTitle
            });
        }

        public List<string> GetSchduleExamIdByExamId(string examId)
        {
            return this.GetAllScheduleExamsBal().Where(x => x.ExamId == examId).Select(x => x.Id).ToList();
        }

        public int GetNoOfQuestions(string examId)
        {
            return GetAllExamDetailsBal().SingleOrDefault(x=>x.ExamId==examId).NoOfQuestions;
        }

        public bool CheckExamIdExistsInExamDetails(string examId)
        {
            return GetAllExamDetailsBal().Any(x => x.ExamId == examId);
        }
    }
}

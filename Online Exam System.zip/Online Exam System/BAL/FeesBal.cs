﻿using DAL;
using System;
using System.Collections.Generic;
using System.Data;
using DTO;

namespace BAL
{
    public class FeesBal
    {
        public string GetFeeId()
        {
            FeesDal feesDal = new FeesDal();
            return "F" + feesDal.GetFeeId();
        }

        public List<FeesDto> GetAllFeesBal()
        {
            FeesDal feesDal = new FeesDal();
            DataTable fees= feesDal.GetAllFeesDal();
            List<FeesDto> feesDtos = new List<FeesDto>();
            for (int i = 0; i < fees.Rows.Count; i++)
            {
                FeesDto feesDto = new FeesDto();
                feesDto.Id = fees.Rows[i]["Id"].ToString();
                feesDto.ExamId = fees.Rows[i]["ExamId"].ToString();
                feesDto.Date = fees.Rows[i]["Date"].ToString();
                feesDto.Amount = Convert.ToInt32(fees.Rows[i]["Amount"]);
                feesDto.ModifiedBy = Convert.ToInt32(fees.Rows[i]["ModifiedBy"]);
                feesDtos.Add(feesDto);
            }
            return feesDtos;
        }

        public FeesDto GetFeesByIdBal(string feeId)
        {
            FeesDal feesDal = new FeesDal();
            DataTable feesById = feesDal.GetFeesByIdDal(feeId);
            FeesDto feesDto = new FeesDto();

            feesDto.Id = feesById.Rows[0]["Id"].ToString();
            feesDto.ExamId = feesById.Rows[0]["ExamId"].ToString();
            feesDto.Date = feesById.Rows[0]["Date"].ToString();
            feesDto.Amount = Convert.ToInt32(feesById.Rows[0]["Amount"]);
            feesDto.ModifiedBy = Convert.ToInt32(feesById.Rows[0]["ModifiedBy"]);

            return feesDto;
        }

        public bool UpdateFeesBal(FeesDto feesDto)
        {
            FeesDal feesDal = new FeesDal();
            bool status = feesDal.UpdateFeesDal(feesDto);
            return status;
        }

        public bool InsertFeesBal(FeesDto feesDto)
        {
            FeesDal feesDal = new FeesDal();
            bool status = feesDal.InsertFeesDal(feesDto);
            return status;
        }

        public bool DeleteFeesBal(string feeId)
        {
            FeesDal feesDal = new FeesDal();
            bool status = feesDal.DeleteFeesDal(feeId);
            return status;
        }
    }
}

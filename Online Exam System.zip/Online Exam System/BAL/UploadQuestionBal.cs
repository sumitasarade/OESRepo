﻿using DAL;
using System;
using System.Collections.Generic;
using System.Data;
using DTO;
using System.Linq;

namespace BAL
{
    public class UploadQuestionBal
    {
        public List<UploadQuestionDto> GetAllUploadedQuestionBal()
        {
            UploadQuestionDal uploadQuestionDal = new UploadQuestionDal();
            DataTable uploadQuestions = uploadQuestionDal.GetAllUploadedQuestionDal();
            List<UploadQuestionDto> uploadQuestionsDtos = new List<UploadQuestionDto>();
            for (int i = 0; i < uploadQuestions.Rows.Count; i++)
            {
                UploadQuestionDto uploadQuestionsDto = new UploadQuestionDto();
                uploadQuestionsDto.Id = Convert.ToInt32(uploadQuestions.Rows[i]["Id"]);
                uploadQuestionsDto.ExamId = uploadQuestions.Rows[i]["ExamId"].ToString();
                uploadQuestionsDto.Question = uploadQuestions.Rows[i]["Question"].ToString();
                uploadQuestionsDto.Option1 = uploadQuestions.Rows[i]["Option1"].ToString();
                uploadQuestionsDto.Option2 = uploadQuestions.Rows[i]["Option2"].ToString();
                uploadQuestionsDto.Option3 = uploadQuestions.Rows[i]["Option3"].ToString();
                uploadQuestionsDto.Option4 = uploadQuestions.Rows[i]["Option4"].ToString();
                uploadQuestionsDto.CorrectAnswer = uploadQuestions.Rows[i]["CorrectAnswer"].ToString();
                uploadQuestionsDto.Date = uploadQuestions.Rows[i]["Date"].ToString();
                uploadQuestionsDto.ModifiedBy = Convert.ToInt32(uploadQuestions.Rows[i]["ModifiedBy"]);
                uploadQuestionsDtos.Add(uploadQuestionsDto);
            }
            return uploadQuestionsDtos;
        }

        public UploadQuestionDto GetUploadedQuestionByIdBal(string uploadQuestionId)
        {
            UploadQuestionDal uploadQuestionDal = new UploadQuestionDal();
            DataTable uploadQuestionsById = uploadQuestionDal.GetUploadedQuestionByIdDal(uploadQuestionId);
            UploadQuestionDto uploadQuestionsDto = new UploadQuestionDto();

            uploadQuestionsDto.Id = Convert.ToInt32(uploadQuestionsById.Rows[0]["Id"]);
            uploadQuestionsDto.ExamId = uploadQuestionsById.Rows[0]["ExamId"].ToString();
            uploadQuestionsDto.Question = uploadQuestionsById.Rows[0]["Question"].ToString();
            uploadQuestionsDto.Option1 = uploadQuestionsById.Rows[0]["Option1"].ToString();
            uploadQuestionsDto.Option2 = uploadQuestionsById.Rows[0]["Option2"].ToString();
            uploadQuestionsDto.Option3 = uploadQuestionsById.Rows[0]["Option3"].ToString();
            uploadQuestionsDto.Option4 = uploadQuestionsById.Rows[0]["Option4"].ToString();
            uploadQuestionsDto.CorrectAnswer = uploadQuestionsById.Rows[0]["CorrectAnswer"].ToString();
            uploadQuestionsDto.Date = uploadQuestionsById.Rows[0]["Date"].ToString();
            uploadQuestionsDto.ModifiedBy = Convert.ToInt32(uploadQuestionsById.Rows[0]["ModifiedBy"]);

            return uploadQuestionsDto;
        }

        public bool UpdateUploadedQuestionBal(UploadQuestionDto uploadQuestionsDto)
        {
            UploadQuestionDal uploadQuestionDal = new UploadQuestionDal();
            bool status = uploadQuestionDal.UpdateUploadedQuestionDal(uploadQuestionsDto);
            return status;
        }

        public bool InsertUploadQuestionBal(UploadQuestionDto uploadQuestionsDto)
        {
            UploadQuestionDal uploadQuestionDal = new UploadQuestionDal();
            bool status = uploadQuestionDal.InsertUploadedQuestionDal(uploadQuestionsDto);
            return status;
        }

        public bool DeleteUploadedQuestionDal(string uploadQuestionId)
        {
            UploadQuestionDal uploadQuestionDal = new UploadQuestionDal();
            bool status = uploadQuestionDal.DeleteUploadedQuestionDal(uploadQuestionId);
            return status;
        }

        public List<UploadQuestionDto> GetUploadedQuestionByExamIdBal(string examId)
        {
            return this.GetAllUploadedQuestionBal().Where(x => x.ExamId == examId).ToList();
        }

        public int GetCountOfExamIds(string examId)
        {
            return GetAllUploadedQuestionBal().Count(x => x.ExamId == examId);
        }
    }
}

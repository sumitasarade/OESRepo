﻿using DAL;
using DTO;
using System;
using System.Collections.Generic;
using System.Data;

namespace BAL
{
    public class StudentResultBal
    {
        public List<StudentResultDto> GetAllStudentResultBal()
        {
            StudentResultDal studentResultDal = new StudentResultDal();
            DataTable studentResults = studentResultDal.GetAllStudentResultDal();
            List<StudentResultDto> studentResultDtos = new List<StudentResultDto>();
            for (int i = 0; i < studentResults.Rows.Count; i++)
            {
                StudentResultDto studentResultDto = new StudentResultDto();
                studentResultDto.Id = Convert.ToInt32(studentResults.Rows[i]["Id"]);
                studentResultDto.ExamId = studentResults.Rows[i]["ExamId"].ToString();
                studentResultDto.ObtainedMarks = Convert.ToInt32(studentResults.Rows[i]["ObtainedMarks"]);
                studentResultDto.Percentage = Convert.ToDouble(studentResults.Rows[i]["Percentage"]);
                studentResultDto.Score = Convert.ToInt32(studentResults.Rows[i]["Score"]);
                studentResultDto.Status = Convert.ToBoolean(studentResults.Rows[i]["Status"]);
                studentResultDto.ExamDate = studentResults.Rows[i]["ExamDate"].ToString();
                studentResultDto.ModifiedBy = Convert.ToInt32(studentResults.Rows[i]["ModifiedBy"]);
                studentResultDto.ModifiedDate = studentResults.Rows[i]["ModifiedDate"].ToString();
                studentResultDtos.Add(studentResultDto);
            }
            return studentResultDtos;
        }

        public StudentResultDto GetStudentResultByIdBal(int studentResultId)
        {
            StudentResultDal studentResultDal = new StudentResultDal();
            DataTable studentResults = studentResultDal.GetStudentResultByIdDal(studentResultId);
            StudentResultDto studentResultDto = new StudentResultDto();

            studentResultDto.Id = Convert.ToInt32(studentResults.Rows[0]["Id"]);
            studentResultDto.ExamId = studentResults.Rows[0]["ExamId"].ToString();
            studentResultDto.ObtainedMarks = Convert.ToInt32(studentResults.Rows[0]["ObtainedMarks"]);
            studentResultDto.Percentage = Convert.ToDouble(studentResults.Rows[0]["Percentage"]);
            studentResultDto.Score = Convert.ToInt32(studentResults.Rows[0]["Score"]);
            studentResultDto.Status = Convert.ToBoolean(studentResults.Rows[0]["Status"]);
            studentResultDto.ExamDate = studentResults.Rows[0]["ExamDate"].ToString();
            studentResultDto.ModifiedBy = Convert.ToInt32(studentResults.Rows[0]["ModifiedBy"]);
            studentResultDto.ModifiedDate = studentResults.Rows[0]["ModifiedDate"].ToString();
            return studentResultDto;
        }

        public bool UpdateStudentResultBal(StudentResultDto studentResultDto)
        {
            StudentResultDal studentResultDal = new StudentResultDal();
            bool status = studentResultDal.UpdateStudentResultDal(studentResultDto);
            return status;
        }

        public bool InsertStudentResultBal(StudentResultDto studentResultDto)
        {
            StudentResultDal studentResultDal = new StudentResultDal();
            bool status = studentResultDal.InsertStudentResultnDal(studentResultDto);
            return status;
        }

        public bool DeleteStudentResultDal(int studentResultId)
        {
            StudentResultDal studentResultDal = new StudentResultDal();
            bool status = studentResultDal.DeleteStudentResultDal(studentResultId);
            return status;
        }
    }
}

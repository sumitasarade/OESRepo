﻿using DTO;
using System;
using System.Collections.Generic;
using System.Data;
using DAL;
using System.Linq;

namespace BAL
{
    public class AnswerGivenBal
    {
        public List<AnswerGivenDto> GetAllAnswerBal()
        {
            AnswerGivenDal answersDal = new AnswerGivenDal();
            DataTable answers = answersDal.GetAllAnswersDal();
            List<AnswerGivenDto> answersDtos = new List<AnswerGivenDto>();
            for (int i = 0; i < answers.Rows.Count; i++)
            {
                AnswerGivenDto answersDto = new AnswerGivenDto();
                answersDto.Id = Convert.ToInt32(answers.Rows[i]["Id"]);
                answersDto.UserId = Convert.ToInt32(answers.Rows[i]["UserId"]);
                answersDto.QuestionId = Convert.ToInt32(answers.Rows[i]["QuestionId"]);
                answersDto.AnswerGivenByStudent = answers.Rows[i]["AnswerGivenByStudent"].ToString();
                answersDto.IsCorrect = Convert.ToInt32(answers.Rows[i]["IsCorrect"]);
                answersDto.ExamDate = answers.Rows[i]["ExamDate"].ToString();
                answersDto.ExamTime = answers.Rows[i]["ExamTime"].ToString();
                answersDtos.Add(answersDto);
            }
            return answersDtos;
        }

        public AnswerGivenDto GetAnswerByIdBal(string answerId)
        {
            AnswerGivenDal answerDal = new AnswerGivenDal();
            DataTable answer = answerDal.GetAnswerByIdDal(answerId);
            AnswerGivenDto answersDto = new AnswerGivenDto();

            answersDto.Id = Convert.ToInt32(answer.Rows[0]["Id"]);
            answersDto.UserId = Convert.ToInt32(answer.Rows[0]["UserId"]);
            answersDto.QuestionId = Convert.ToInt32(answer.Rows[0]["QuestionId"]);
            answersDto.AnswerGivenByStudent = answer.Rows[0]["AnswerGivenByStudent"].ToString();
            answersDto.IsCorrect = Convert.ToInt32(answer.Rows[0]["IsCorrect"]);
            answersDto.ExamDate = answer.Rows[0]["ExamDate"].ToString();
            answersDto.ExamTime = answer.Rows[0]["ExamTime"].ToString();
            return answersDto;
        }

        public bool UpdateAnswerBal(AnswerGivenDto answersDto)
        {
            AnswerGivenDal answerDal = new AnswerGivenDal();
            bool status = answerDal.UpdateAnswerDal(answersDto);
            return status;
        }

        public bool InsertAnswerGivenBal(AnswerGivenDto answersDto)
        {
            AnswerGivenDal answerDal = new AnswerGivenDal();
            bool status = answerDal.InsertAnswerDal(answersDto);
            return status;
        }

        public bool DeleteAnswerGivenBal(int id)
        {
            AnswerGivenDal answerGivenDal = new AnswerGivenDal();
            bool status = answerGivenDal.DeleteAnswerGivenDal(id);
            return status;
        }

        public int GetAnswerIdByQuestionId(int questionId)
        {
            var q= this.GetAllAnswerBal().Any(x => x.QuestionId == questionId);
            if(q==true)
            {
                return this.GetAllAnswerBal().SingleOrDefault(x => x.QuestionId == questionId).Id;
            }
            else
            {
                return 0;
            }
        }

        public List<AnswerGivenDto> GetAnswerIds(int userId, string examDate, string examTime)
        {
            return this.GetAllAnswerBal().Where(x => x.UserId == userId && x.ExamDate == examDate && x.ExamTime == examTime).ToList();
        }
    }
}

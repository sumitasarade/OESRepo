﻿using DTO;
using System;
using System.Collections.Generic;
using System.Data;
using DAL;
using System.Linq;

namespace BAL
{
    public class StudentBal
    {
        public List<StudentDto> GetAllStudentBal()
        {
            StudentDal studentsDal = new StudentDal();
            DataTable students = studentsDal.GetAllStudentsDal();
            List<StudentDto> studentDtos = new List<StudentDto>();
            for (int i = 0; i < students.Rows.Count; i++)
            {
                StudentDto studentDto = new StudentDto();
                studentDto.Id = Convert.ToInt32(students.Rows[i]["Id"]);
                studentDto.Name = students.Rows[i]["Name"].ToString();
                studentDto.ParentsName = students.Rows[i]["ParentsName"].ToString();
                studentDto.RollNo = Convert.ToInt32(students.Rows[i]["RollNo"]);
                studentDto.Gender = Convert.ToInt32(students.Rows[i]["Gender"]);
                studentDto.UserId = Convert.ToInt32(students.Rows[i]["UserId"]);
                studentDtos.Add(studentDto);
            }
            return studentDtos;
        }

        public StudentDto GetStudentByIdBal(string studentId)
        {
            StudentDal studentDal = new StudentDal();
            DataTable student = studentDal.GetStudentByIdDal(studentId);
            StudentDto studentDto = new StudentDto();

            studentDto.Id = Convert.ToInt32(student.Rows[0]["Id"]);
            studentDto.Name = student.Rows[0]["Name"].ToString();
            studentDto.ParentsName = student.Rows[0]["ParentsName"].ToString();
            studentDto.RollNo = Convert.ToInt32(student.Rows[0]["RollNo"]);
            studentDto.Gender = Convert.ToInt32(student.Rows[0]["Gender"]);
            studentDto.UserId = Convert.ToInt32(student.Rows[0]["UserId"]);

            return studentDto;
        }

        public bool UpdateStudentBal(StudentDto studentDto)
        {
            StudentDal studentDal = new StudentDal();
            bool status = studentDal.UpdateStudentDal(studentDto);
            return status;
        }

        public bool InsertStudentBal(StudentDto studentDto)
        {
            StudentDal studentDal = new StudentDal();
            bool status = studentDal.InsertStudentDal(studentDto);
            return status;
        }

        public bool DeleteStudentBal(int id)
        {
            StudentDal studentDal = new StudentDal();
            bool status = studentDal.DeleteStudentDal(id);
            return status;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OES.Models
{
    public class QuestionAnswerViewModel
    {
        public QuestionAnswerViewModel()
        {
            QuestionAnswers = new List<QuestionAnswer>();
        }
        public List<QuestionAnswer> QuestionAnswers { get; set; }
        public string ExamDate { get; set; }
        public string ExamTime { get; set; }
        public string ExamTitle { get; set; }
        public string ExamId { get; set; }
    }

    public class QuestionAnswer
    {
        //public UploadQuestion UploadQuestion { get; set; }
        public int QuestionId { get; set; }
        public string Question { get; set; }
        public string Option1 { get; set; }
        public string Option2 { get; set; }
        public string Option3 { get; set; }
        public string Option4 { get; set; }
        public string CorrectAnswer { get; set; }
        public string Date { get; set; }
        public int CreatedBy { get; set; }

        //public AnswerGiven AnswerGiven { get; set; }
        public int AnswerId { get; set; }
        public int StudentId { get; set; }
        public string SelectedOption { get; set; }
        public int IsCorrect { get; set; }
    }
}


﻿using System.Collections.Generic;

namespace OES.Models
{
    public class ExamDetailsViewModel
    {
        public ExamDetailsViewModel()
        {
            this.ScheduleExamList = new List<ScheduleExam>();
        }
        public int Id { get; set; }
        public string ExamId { get; set; }
        public string ExamTitle { get; set; }
        public string ExamType { get; set; }
        public int NoOfTests { get; set; }
        public string Description { get; set; }
        public int PassingMarks { get; set; }
        public int TotalMarks { get; set; }
        public int NoOfQuestions { get; set; }
        public string Date { get; set; }
        public int ModifiedBy { get; set; }
        public List<ScheduleExam> ScheduleExamList { get; set; }
    }

    public class ScheduleExam
    {
        public string Date { get; set; }
        public string Time { get; set; }
        public decimal Duration { get; set; }
    }
}
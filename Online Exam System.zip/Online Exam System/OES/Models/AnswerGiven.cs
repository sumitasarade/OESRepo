﻿namespace OES.Models
{
    public class AnswerGiven
    {
        public int AnswerId { get; set; }
        public int UserId { get; set; }
        public string SelectedOption { get; set; }
        public int IsCorrect { get; set; }
    }
}
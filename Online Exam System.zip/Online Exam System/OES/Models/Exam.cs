﻿namespace OES.Models
{
    public class Exam
    {
        public string Id { get; set; }
        public string ExamTitle { get; set; }
        public string ModifiedBy { get; internal set; }
        public string ModifiedDate { get; internal set; }
    }
}
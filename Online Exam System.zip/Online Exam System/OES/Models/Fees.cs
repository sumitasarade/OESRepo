﻿namespace OES.Models
{
    public class Fees
    {
        public string Id { get; set; }
        public string ExamId { get; set; }
        public string ExamTitle { get; set; }
        public int Amount { get; set; }
        public string Date { get; set; }
        public int ModifiedBy { get; set; }
    }
}
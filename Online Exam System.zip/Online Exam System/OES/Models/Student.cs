﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OES.Models
{
    public class Student
    {
        public string Name { get; set; }
        public int RollNo { get; set; }
        public string ParentsName { get; set; }
        public int Gender { get; set; }
        public int UserId { get; set; }
    }
}
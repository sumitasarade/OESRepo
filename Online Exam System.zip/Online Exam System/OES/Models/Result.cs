﻿using System;

namespace OES.Models
{
    public class Result
    {
        public int Id { get; set; }
        public string ExamTitle { get; set; }
        public int ObtainedMarks { get; set; }
        public double Percentage { get; set; }
        public bool Status { get; set; }
        public string ExamDate { get; set; }
        public int TotalMarks { get; set; }
        public int PassingMarks { get; set; }
        //public Decimal Duration { get; set; }
        public string ModifiedBy { get; set; }
    }
}
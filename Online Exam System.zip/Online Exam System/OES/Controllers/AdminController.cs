﻿using BAL;
using DTO;
using OES.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace OES.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        // GET: Admin
      
        public ActionResult Dashboard()
        {
            return View();
        }

        public ActionResult Result()
        {
            return View();
        }

        public ActionResult Parents()
        {
            return View();
        }

        public ActionResult AllStudentRecords()
        {
            UserBal userBal = new UserBal();
            StudentBal studentBal = new StudentBal();
            List<StudentDto> studentDtos = studentBal.GetAllStudentBal();
            List<UserDto> userDtos = userBal.GetUsersByRoleBal(2);
            List<User> users = new List<User>();
            foreach (var item in userDtos)
            {                
                User user = new User();
                StudentDto studentDto = studentDtos.SingleOrDefault(x => x.UserId == item.Id);
                user.UserName = item.UserName;
                user.Email = item.Email;
                user.MobileNo = item.MobileNo;
                user.ParentsName = studentDto.ParentsName;
                user.Name = studentDto.Name;
                user.RollNo = studentDto.RollNo;
                user.Gender = studentDto.Gender;                
                users.Add(user);
            }
            return View(users);
        }


        //public ActionResult ViewAllTeacherRecords()
        //{
        //    UserBal userBal = new UserBal();
        //    List<UserDto> userDtos = userBal.GetUsersByRoleBal(2);
        //    List<User> users = new List<User>();
        //    foreach (var item in userDtos)
        //    {
        //        User user = new User();
        //        user.UserName = item.UserName;
        //        user.Email = item.Email;
        //        user.MobileNo = item.MobileNo;
        //        users.Add(user);
        //    }
        //    return View(users);
        //}
    }
}
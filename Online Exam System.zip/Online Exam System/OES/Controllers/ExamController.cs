﻿using BAL;
using DTO;
using OES.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace OES.Controllers
{
    [Authorize(Roles = "Admin, Teacher, Student")]
    public class ExamController : Controller
    {
        // GET: Exam
        public ActionResult AllExams()
        {
            ExamBal examBal = new ExamBal();
            List<ExamDto> examDtos = examBal.GetAllExamsBal();
            List<Exam> examList = new List<Exam>();
            UserBal userBal = new UserBal();
            
            foreach (var item in examDtos)
            {
                Exam exam = new Exam
                {
                    Id = item.Id,
                    ExamTitle = item.ExamTitle,
                    ModifiedBy = userBal.GetUserByIdBal(item.ModifiedBy).UserName,
                    ModifiedDate = item.ModifiedDate
                };

                examList.Add(exam);

            }
            return View(examList);
        }

        public ActionResult AddExam()
        {
            ExamBal examBal = new ExamBal();
            Exam exam = new Exam
            {
                Id = examBal.GetExamId()
            };
            return View(exam);
        }

        [HttpPost]
        public ActionResult AddExam(Exam exam)
        {
            ExamBal examBal = new ExamBal();
            ExamDto examDto = new ExamDto();

            bool checkExamTitleExists = examBal.CheckExamTitleExists(examDto.ExamTitle);
            if (checkExamTitleExists == false)
            {
                examDto.Id = exam.Id;
                examDto.ExamTitle = exam.ExamTitle;
                examDto.ModifiedBy = Convert.ToInt32(Session["UserId"]);
                examDto.ModifiedDate = DateTime.Now.ToShortDateString();
                examBal.InsertExamBal(examDto);
            }
            return RedirectToAction("AllExams", "Exam");
        }

        [HttpGet]
        public ActionResult EditExam(string id)
        {
            ExamBal examBal = new ExamBal();
            ExamDto examDto = examBal.GetExamByIdBal(id);
            Exam exam = new Exam();
            UserBal userBal = new UserBal();
            exam.Id = exam.Id;
            exam.ExamTitle = examDto.ExamTitle;
            exam.ModifiedBy = userBal.GetUserByIdBal(examDto.ModifiedBy).UserName;
            exam.ModifiedDate = examDto.ModifiedDate;
            return View(exam);
        }

        [HttpPost]
        public ActionResult EditExam(Exam exam)
        {
            ExamBal examBal = new ExamBal();
            ExamDto examDto = new ExamDto
            {
                Id = exam.Id,
                ExamTitle = exam.ExamTitle,
                ModifiedBy = Convert.ToInt32(Session["UserId"]),
                ModifiedDate = DateTime.Now.ToShortDateString()
            };

            examBal.UpdateExamBal(examDto);
            return RedirectToAction("AllExams", "Exam");
        }

        public JsonResult DeleteExam(string id)
        {
            ExamBal examBal = new ExamBal();
            examBal.DeleteExamBal(id);
            return Json(true, JsonRequestBehavior.AllowGet);
        }

        public ActionResult SetExam()
        {
            ExamBal examBal = new ExamBal();
            //List<string> examTitles = examBal.GetExamTitleList();
            ////IEnumerable<SelectListItem> examTitleList = examBal.GetExamTitleList();
            //foreach (var item in examTitleList)
            //{
            //    if(examBal.CheckExamTitleExistsInExamDetails(item.))
            //}
            //ViewBag.ExamTitleDropDown = examTitleList;
            //ExamDetailsViewModel examDetails = new ExamDetailsViewModel();
            //return View(examDetails);
            return View();
        }

        public ActionResult InsertExamDetails(ExamDetailsViewModel examDetails)
        {
            ExamBal examBal = new ExamBal();

            string examId = examDetails.ExamId;
            int userId = Convert.ToInt32(Session["UserId"]);
            string date = DateTime.Now.ToShortDateString();

            ExamDetailsDto examDetailsDto = new ExamDetailsDto();
            examDetailsDto.ExamId = examId;
            examDetailsDto.ExamType = examDetails.ExamType;
            examDetailsDto.Date = examDetails.Date;
            examDetailsDto.Description = examDetails.Description;
            examDetailsDto.NoOfQuestions = examDetails.NoOfQuestions;
            examDetailsDto.NoOfTests = examDetails.NoOfTests;
            examDetailsDto.PassingMarks = examDetails.PassingMarks;
            examDetailsDto.TotalMarks = examDetails.TotalMarks;
            examDetailsDto.ModifiedBy = userId;
            examDetailsDto.Date = date;

            examBal.InsertExamDetailsBal(examDetailsDto);

            foreach (var item in examDetails.ScheduleExamList)
            {
                ScheduleExamDto scheduleExamDto = new ScheduleExamDto();
                scheduleExamDto.ExamId = examId;
                scheduleExamDto.Date = item.Date;
                scheduleExamDto.Time = item.Time;
                scheduleExamDto.Duration = item.Duration;
                scheduleExamDto.ModifiedBy = userId;
                scheduleExamDto.ModifiedDate = date;
                examBal.InsertScheduleExamBal(scheduleExamDto);
            }
            Session["ExamId"] = "E2023";
            return RedirectToAction("AddQuestions", "Admin");
        }

        //public ActionResult ScheduleExam()
        //{
        //    ExamBal examBal = new ExamBal();
        //    List<ScheduleExamDto> scheduleExamDtos = examBal.GetAllScheduleExamsBal();
        //    List<ScheduleExam> scheduleExamList = new List<ScheduleExam>();

        //    foreach (var item in scheduleExamDtos)
        //    {
        //        ScheduleExam scheduleExam = new ScheduleExam
        //        {
        //            Id = item.Id,
        //            ExamId = item.ExamId,
        //            ExamTitle = examBal.GetExamByIdBal(item.ExamId).ExamTitle,
        //            Date = item.Date,
        //            Time = item.Time,
        //            Duration = item.Duration,
        //            ModifiedBy=item.ModifiedBy
        //        };

        //        scheduleExamList.Add(scheduleExam);

        //    }
        //    return View(scheduleExamList);
        //}

        //public ActionResult AddScheduleExam()
        //{
        //    ExamBal examBal = new ExamBal();
        //    IEnumerable<SelectListItem> examTitleList = examBal.GetExamTitleList();
        //    ViewBag.ExamTitleDropDown = examTitleList;

        //    ScheduleExam scheduleExam = new ScheduleExam
        //    {
        //        Id = examBal.GetScheduleExamId()
        //    };
        //    return View(scheduleExam);
        //}

        //[HttpPost]
        //public ActionResult AddScheduleExam(ScheduleExam scheduleExam)
        //{
        //    ScheduleExamDto scheduleExamDto = new ScheduleExamDto();
        //    ExamBal examBal = new ExamBal();

        //    scheduleExamDto.Id = scheduleExam.Id;
        //    scheduleExamDto.ExamId = scheduleExam.ExamId;
        //    scheduleExamDto.Date = scheduleExam.Date;
        //    scheduleExamDto.Time = scheduleExam.Time;
        //    scheduleExamDto.Duration = scheduleExam.Duration;
        //    scheduleExamDto.ModifiedBy = Convert.ToInt32(Session["UserId"]);

        //    examBal.InsertScheduleExamBal(scheduleExamDto);

        //    return RedirectToAction("ScheduleExam", "Exam");
        //}

        //public ActionResult EditScheduleExam(string id)
        //{
        //    ExamBal examBal = new ExamBal();
        //    IEnumerable<SelectListItem> examTitleList = examBal.GetExamTitleList();
        //    ViewBag.ExamTitleDropDown = examTitleList;

        //    ScheduleExamDto scheduleExamDto = examBal.GetScheduleExamByIdBal(id);
        //    ScheduleExam scheduleExam = new ScheduleExam
        //    {
        //        Id = scheduleExamDto.Id,
        //        ExamId = scheduleExamDto.ExamId,
        //        Date = scheduleExamDto.Date,
        //        Time = scheduleExamDto.Time,
        //        Duration = scheduleExamDto.Duration,
        //        ModifiedBy=scheduleExamDto.ModifiedBy
        //    };

        //    return View(scheduleExam);
        //}

        //[HttpPost]
        //public ActionResult EditScheduleExam(ScheduleExam scheduleExam)
        //{
        //    ExamBal examBal = new ExamBal();
        //    ScheduleExamDto scheduleExamDto = new ScheduleExamDto
        //    {
        //        Id = scheduleExam.Id,
        //        ExamId = scheduleExam.ExamId,
        //        Date = scheduleExam.Date,
        //        Time = scheduleExam.Time,
        //        Duration = scheduleExam.Duration,
        //        ModifiedBy= Convert.ToInt32(Session["UserId"])
        //    };

        //    examBal.UpdateScheduleExamBal(scheduleExamDto);
        //    return RedirectToAction("ScheduleExam", "Exam");
        //}

        //public JsonResult DeleteScheduleExam(string id)
        //{
        //    ExamBal examBal = new ExamBal();
        //    examBal.DeleteScheduleExamBal(id);
        //    return Json(true, JsonRequestBehavior.AllowGet);
        //}

        public ActionResult ChoosePaper()
        {
            ExamBal examBal = new ExamBal();
            IEnumerable<SelectListItem> examTitleList = examBal.GetExamTitleList();
            ViewBag.ExamTitleDropDown = examTitleList;
            return View();
        }

        public ActionResult Information()
        {
            return View();
        }

        public ActionResult Instruction(UploadQuestion uploadQuestion)
        {
            return View(uploadQuestion);
        }

        public ActionResult SolveQuestionPaper(string examId)
        {
            QuestionAnswerViewModel model = new QuestionAnswerViewModel();
            UploadQuestionBal uploadQuestionBal = new UploadQuestionBal();
            ExamBal examBal = new ExamBal();
            List<UploadQuestionDto> uploadQuestionDtos = uploadQuestionBal.GetUploadedQuestionByExamIdBal(examId);
            model.ExamTitle = examBal.GetExamByIdBal(examId).ExamTitle;

            foreach (var item in uploadQuestionDtos)
            {
                QuestionAnswer questionAnswer = new QuestionAnswer();
                questionAnswer.QuestionId = item.Id;
                questionAnswer.Question = item.Question;
                questionAnswer.Option1 = item.Option1;
                questionAnswer.Option2 = item.Option2;
                questionAnswer.Option3 = item.Option3;
                questionAnswer.Option4 = item.Option4;
                questionAnswer.CorrectAnswer = item.CorrectAnswer;
                questionAnswer.Date = item.Date;
                questionAnswer.CreatedBy = 2;
                //CreatedBy = item.CreatedBy;               
                model.QuestionAnswers.Add(questionAnswer);
            }
            model.ExamDate = DateTime.Now.ToShortDateString();
            model.ExamTime = DateTime.Now.ToShortTimeString();
            return View(model);
        }

        [HttpPost]
        public ActionResult SolveQuestionPaper(QuestionAnswerViewModel model)
        {
            AnswerGivenBal answerGivenBal = new AnswerGivenBal();

            StudentResultDto studentResultDto = new StudentResultDto();
            ExamBal examBal = new ExamBal();

            foreach (var item in model.QuestionAnswers)
            {
                AnswerGivenDto answerDto = new AnswerGivenDto();
                answerDto.QuestionId = item.QuestionId;

                if (item.SelectedOption != null)
                {
                    answerDto.AnswerGivenByStudent = item.SelectedOption;
                }
                else
                {
                    answerDto.AnswerGivenByStudent = null;
                }
                if (item.CorrectAnswer.Equals(item.SelectedOption))
                {
                    answerDto.IsCorrect = 1;
                    item.IsCorrect = 1;
                }
                else
                {
                    answerDto.IsCorrect = 0;
                    item.IsCorrect = 0;
                }
                answerDto.ExamDate = model.ExamDate;
                answerDto.ExamTime = model.ExamTime;
                answerDto.UserId = Convert.ToInt32(Session["UserId"]);
                answerGivenBal.InsertAnswerGivenBal(answerDto);
            }
            //Adding records to StudentResult Table

            int countOfIsCorrect = model.QuestionAnswers.Where(x => x.IsCorrect == 1).Count();
            ExamDetailsDto examDetailsDto = examBal.GetAllExamDetailsBal().SingleOrDefault(x => x.ExamId == model.ExamId);
            int totalMarks = examDetailsDto.TotalMarks;
            int obtainedMarks = (totalMarks / (examDetailsDto.NoOfQuestions)) * (countOfIsCorrect);
            studentResultDto.ObtainedMarks = obtainedMarks;
            studentResultDto.Percentage = (obtainedMarks * 100) / totalMarks;
            if (obtainedMarks > examDetailsDto.PassingMarks)
            {
                studentResultDto.Status = true;
            }
            else
            {
                studentResultDto.Status = false;
            }
            studentResultDto.ExamId = model.ExamId;
            studentResultDto.ExamDate = model.ExamDate;
            int userId = Convert.ToInt32(Session["UserId"]);
            studentResultDto.ModifiedBy = userId;
            studentResultDto.ModifiedDate = DateTime.Now.ToShortDateString();

            UserBal userBal = new UserBal();
            int roleId = userBal.GetUserByIdBal(userId).RoleId;
            if (roleId == 2)
            {
                StudentResultBal studentResultBal = new StudentResultBal();
                studentResultBal.InsertStudentResultBal(studentResultDto);
            }

            string userName = userBal.GetUserByIdBal(userId).UserName;

            //Converting from StudentResultDto to StudentResult
            Result result = new Result()
            {
                ObtainedMarks = studentResultDto.ObtainedMarks,
                Percentage = studentResultDto.Percentage,
                Status = studentResultDto.Status,
                ExamDate = studentResultDto.ExamDate,
                TotalMarks = totalMarks,
                PassingMarks = examDetailsDto.PassingMarks,
                ExamTitle = examBal.GetExamByIdBal(model.ExamId).ExamTitle,
                ModifiedBy = userName,
                //Duration=
            };
            Session["Result"] = result;
            return RedirectToAction("ViewResult");
        }

        public ActionResult ViewResult()
        {
            Result result = (Result)Session["Result"];
            return View(result);
        }

        public ActionResult ResultOfAllStudents()
        {
            List<Result> results = new List<Result>();
            StudentResultBal resultBal = new StudentResultBal();
            List<StudentResultDto> resultDtos = resultBal.GetAllStudentResultBal();

            ExamBal examBal = new ExamBal();
            UserBal userBal = new UserBal();
            List<ExamDto> examDtos = examBal.GetAllExamsBal();
            List<ExamDetailsDto> examDetailsDtos = examBal.GetAllExamDetailsBal();
            List<UserDto> userDtos = userBal.GetAllUserBal();

            foreach (var item in resultDtos)
            {
                Result result = new Result();
                ExamDetailsDto examDetailsDto = examDetailsDtos.SingleOrDefault(x => x.ExamId == item.ExamId);
                result.ExamTitle = examDtos.SingleOrDefault(x => x.Id==item.ExamId).ExamTitle;
                result.ObtainedMarks = item.ObtainedMarks;
                result.Percentage = item.Percentage;
                result.Status = item.Status;
                result.ExamDate = item.ExamDate;
                result.TotalMarks = examDetailsDto.TotalMarks;
                result.PassingMarks = examDetailsDto.PassingMarks;
                result.ModifiedBy = userDtos.SingleOrDefault(x => x.Id == item.ModifiedBy).UserName;
                results.Add(result);
            }
            return View(results);
        }

        public ActionResult EditExamDetails(int id)
        {
            ExamBal examBal = new ExamBal();
            IEnumerable<SelectListItem> examTitleList = examBal.GetExamTitleList();
            ViewBag.ExamTitleDropDown = examTitleList;

            ExamDetailsDto examDetailsDto = examBal.GetExamDetailsByIdBal(id);
            ExamDetailsViewModel examDetails = new ExamDetailsViewModel();

            examDetails.Id = examDetailsDto.Id;
            examDetails.ExamId = examDetailsDto.ExamId;
            examDetails.ExamType = examDetailsDto.ExamType;
            examDetails.NoOfTests = examDetailsDto.NoOfTests;
            examDetails.Description = examDetailsDto.Description;
            examDetails.PassingMarks = examDetailsDto.PassingMarks;
            examDetails.TotalMarks = examDetailsDto.TotalMarks;
            examDetails.NoOfQuestions = examDetailsDto.NoOfQuestions;
            examDetails.Date = examDetailsDto.Date;
            examDetails.ModifiedBy = Convert.ToInt32(Session["UserId"]);

            return View(examDetails);
        }

        [HttpPost]
        public ActionResult EditExamDetails(ExamDetailsViewModel examDetails)
        {
            ExamBal examBal = new ExamBal();
            ExamDetailsDto examDetailsDto = new ExamDetailsDto();

            examDetailsDto.Id = examDetails.Id;
            examDetailsDto.ExamId = examDetails.ExamId;
            examDetailsDto.ExamType = examDetails.ExamType;
            examDetailsDto.NoOfTests = examDetails.NoOfTests;
            examDetailsDto.Description = examDetails.Description;
            examDetailsDto.PassingMarks = examDetails.PassingMarks;
            examDetailsDto.TotalMarks = examDetails.TotalMarks;
            examDetailsDto.NoOfQuestions = examDetails.NoOfQuestions;
            examDetailsDto.Date = examDetails.Date;
            examDetailsDto.ModifiedBy = Convert.ToInt32(Session["UserId"]);

            examBal.UpdateExamDetailsBal(examDetailsDto);

            return View();
        }

        public ActionResult ExamDetails()
        {
            ExamBal examBal = new ExamBal();
            List<ExamDetailsDto> examDetailsDtos = examBal.GetAllExamDetailsBal();
            List<ExamDetailsViewModel> examDetailList = new List<ExamDetailsViewModel>();

            foreach (var item in examDetailsDtos)
            {
                ExamDetailsViewModel examDetails = new ExamDetailsViewModel
                {
                    ExamId = item.ExamId,
                    ExamType = item.ExamType,
                    NoOfTests = item.NoOfTests,
                    Description = item.Description,
                    PassingMarks = item.PassingMarks,
                    TotalMarks = item.TotalMarks,
                    NoOfQuestions = item.NoOfQuestions,
                    Date = item.Date,
                    ModifiedBy = item.ModifiedBy
                };
                examDetailList.Add(examDetails);
            }
            return View(examDetailList);
        }

        public JsonResult DeleteExamDetails(int id)
        {
            ExamBal examBal = new ExamBal();
            examBal.DeleteExamDetailsBal(id);
            return Json(true, JsonRequestBehavior.AllowGet);
        }

        public ActionResult AllQuestions(string examId)
        {
            UploadQuestionBal uploadQuestionBal = new UploadQuestionBal();
            List<UploadQuestionDto> uploadQuestionDtos = uploadQuestionBal.GetUploadedQuestionByExamIdBal(examId);
            List<UploadQuestion> uploadQuestionList = new List<UploadQuestion>();

            foreach (var item in uploadQuestionDtos)
            {
                UploadQuestion uploadQuestion = new UploadQuestion
                {
                    Id = item.Id,
                    ExamId = item.ExamId,
                    Question = item.Question,
                    Option1 = item.Option1,
                    Option2 = item.Option2,
                    Option3 = item.Option3,
                    Option4 = item.Option4,
                    CorrectAnswer = item.CorrectAnswer,
                    Date = item.Date,
                    ModifiedBy = Convert.ToInt32(Session["UserId"])
                };
                uploadQuestionList.Add(uploadQuestion);
            }
            return View(uploadQuestionList);
        }

        public ActionResult AddQuestions()
        {
            string examId = "E2023";
            UploadQuestion uploadQuestion = new UploadQuestion();
            uploadQuestion.ExamId = examId;

            ExamBal examBal = new ExamBal();
            uploadQuestion.ExamTitle = examBal.GetExamByIdBal(examId).ExamTitle;

            return View(uploadQuestion);
        }

        [HttpPost]
        public ActionResult SetQuestionPaper(UploadQuestion uploadQuestion)
        {
            ExamBal examBal = new ExamBal();
            //Session["ExamId"] = uploadQuestion.ExamId;
            int noOfQuestions = examBal.GetNoOfQuestions(uploadQuestion.ExamId);

            UploadQuestionBal uploadQuestionBal = new UploadQuestionBal();
            int countOfUploadedQuestions = uploadQuestionBal.GetCountOfExamIds(uploadQuestion.ExamId);

            if (countOfUploadedQuestions <= noOfQuestions)
            {

                UploadQuestionDto uploadQuestionDto = new UploadQuestionDto
                {
                    ExamId = uploadQuestion.ExamId,
                    Question = uploadQuestion.Question,
                    Option1 = uploadQuestion.Option1,
                    Option2 = uploadQuestion.Option2,
                    Option3 = uploadQuestion.Option3,
                    Option4 = uploadQuestion.Option4,
                    CorrectAnswer = uploadQuestion.CorrectAnswer,
                    Date = DateTime.Now.ToString(),
                    ModifiedBy = Convert.ToInt32(Session["UserId"])
                };

                uploadQuestionBal.InsertUploadQuestionBal(uploadQuestionDto);
                ScheduleExam scheduleExam = new ScheduleExam();
                //scheduleExam.ExamId = uploadQuestion.ExamId;
                return View(scheduleExam);
            }
            else
            {
                return RedirectToAction("Index", "Teacher");
            }
        }

        [HttpGet]
        public ActionResult EditUploadQuestion(string id)
        {
            ExamBal examBal = new ExamBal();
            IEnumerable<SelectListItem> examTitleList = examBal.GetExamTitleList();
            ViewBag.ExamTitleDropDown = examTitleList;

            UploadQuestionBal uploadQuestionBal = new UploadQuestionBal();
            UploadQuestionDto uploadQuestionDto = uploadQuestionBal.GetUploadedQuestionByIdBal(id);
            UploadQuestion uploadQuestion = new UploadQuestion
            {
                Id = uploadQuestionDto.Id,
                ExamId = uploadQuestionDto.ExamId,
                Question = uploadQuestionDto.Question,
                Option1 = uploadQuestionDto.Option1,
                Option2 = uploadQuestionDto.Option2,
                Option3 = uploadQuestionDto.Option3,
                Option4 = uploadQuestionDto.Option4,
                CorrectAnswer = uploadQuestionDto.CorrectAnswer,
                Date = uploadQuestionDto.Date,
                ModifiedBy = uploadQuestionDto.ModifiedBy
            };

            return View(uploadQuestion);
        }

        [HttpPost]
        public ActionResult EditUploadQuestion(UploadQuestion uploadQuestion)
        {
            UploadQuestionBal uploadQuestionBal = new UploadQuestionBal();
            UploadQuestionDto uploadQuestionDto = new UploadQuestionDto
            {
                Id = uploadQuestion.Id,
                ExamId = uploadQuestion.ExamId,
                Question = uploadQuestion.Question,
                Option1 = uploadQuestion.Option1,
                Option2 = uploadQuestion.Option2,
                Option3 = uploadQuestion.Option3,
                Option4 = uploadQuestion.Option4,
                CorrectAnswer = uploadQuestion.CorrectAnswer,
                Date = uploadQuestion.Date,
                ModifiedBy = Convert.ToInt32(Session["UserId"])
            };

            uploadQuestionBal.UpdateUploadedQuestionBal(uploadQuestionDto);
            return RedirectToAction("Index", "Teacher");
        }

        public JsonResult DeleteUploadQuestion(string id)
        {
            UploadQuestionBal uploadQuestionBal = new UploadQuestionBal();
            uploadQuestionBal.DeleteUploadedQuestionDal(id);
            return Json(true, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ViewQuestionPaper()
        {
            UploadQuestionBal uploadQuestionBal = new UploadQuestionBal();
            //string examId = Session["ExamId"].ToString();
            //string examId = "2023";

            return View();
        }

    }
}
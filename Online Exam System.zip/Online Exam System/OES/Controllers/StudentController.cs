﻿using BAL;
using DTO;
using OES.Models;
using System;
using System.Web.Mvc;

namespace OES.Controllers
{
    [Authorize(Roles = "Student, Admin")]
    public class StudentController : Controller
    {
        // GET: Student
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult EnterStudentInformation()
        {
            return View();
        }

        public ActionResult AddStudentInformation(Student student)
        {
            StudentDto studentDto = new StudentDto()
            {
                Name = student.Name,
                RollNo = student.RollNo,
                ParentsName = student.ParentsName,
                Gender = student.Gender,
                UserId =Convert.ToInt32(Session["UserId"])                
            };
            StudentBal studentBal = new StudentBal();
            studentBal.InsertStudentBal(studentDto);
            return RedirectToAction("ChoosePaper","Exam");
        }
    }
}
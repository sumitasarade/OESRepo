﻿using BAL;
using DTO;
using OES.Models;
using System;
using System.Collections.Generic;
using System.Web.Mvc;

namespace OES.Controllers
{
    [Authorize(Roles = "Teacher, Admin")]
    public class TeacherController : Controller
    {
        // GET: Teacher
        

        public ActionResult Dashboard()
        {
            return View();
        }
         
        

        public ActionResult GetUploadedQuestions()
        {
            UploadQuestionBal uploadQuestionBal = new UploadQuestionBal();
            string examId = Session["ExamId"].ToString();
            List<UploadQuestionDto> uploadQuestionDtos= uploadQuestionBal.GetUploadedQuestionByExamIdBal(examId);
            List<UploadQuestion> uploadQuestionList = new List<UploadQuestion>();

            foreach (var item in uploadQuestionDtos)
            {
                UploadQuestion uploadQuestion = new UploadQuestion
                {
                    Id = item.Id,
                    ExamId = item.ExamId,
                    Question = item.Question,
                    Option1 = item.Option1,
                    Option2 = item.Option2,
                    Option3 = item.Option3,
                    Option4 = item.Option4,
                    CorrectAnswer = item.CorrectAnswer,
                    Date = item.Date,
                    ModifiedBy = item.ModifiedBy
                };

                uploadQuestionList.Add(uploadQuestion);
            }
            return View(uploadQuestionList);
        }

        public ActionResult GetScheduleExamList(string examId)
        {
            ExamBal examBal = new ExamBal();
            List<string> scheduleExamList = examBal.GetSchduleExamIdByExamId(examId);
            

            //JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer();
            //string result = javaScriptSerializer.Serialize(scheduleExamList);
            return Json(scheduleExamList, JsonRequestBehavior.AllowGet);
        }

        public ActionResult AddExamDetails()
        {
            ExamBal examBal = new ExamBal();
            IEnumerable<SelectListItem> examTitleList = examBal.GetExamTitleList();
            ViewBag.ExamTitleDropDown = examTitleList;
            return View();
        }

        [HttpPost]
        public ActionResult AddExamDetails(ExamDetailsViewModel examDetails)
        {
            ExamDetailsDto examDetailsDto = new ExamDetailsDto();
            ExamBal examBal = new ExamBal();
            examDetailsDto.ExamId = examDetails.ExamId;
            examDetailsDto.ExamType = examDetails.ExamType;
            examDetailsDto.NoOfTests = examDetails.NoOfTests;
            examDetailsDto.Description = examDetails.Description;
            examDetailsDto.PassingMarks = examDetails.PassingMarks;
            examDetailsDto.TotalMarks = examDetails.TotalMarks;
            examDetailsDto.NoOfQuestions = examDetails.NoOfQuestions;
            examDetailsDto.Date = DateTime.Now.ToShortDateString();
            examDetailsDto.ModifiedBy = Convert.ToInt32(Session["UserId"]);
            examBal.InsertExamDetailsBal(examDetailsDto);
            
            Session["ExamId"] = examDetails.ExamId;
            return RedirectToAction("AddQuestions","Teacher");
        }

        public ActionResult EditExamDetails(int id)
        {
            ExamBal examBal = new ExamBal();
            IEnumerable<SelectListItem> examTitleList = examBal.GetExamTitleList();
            ViewBag.ExamTitleDropDown = examTitleList;

            ExamDetailsDto examDetailsDto = examBal.GetExamDetailsByIdBal(id);
            ExamDetailsViewModel examDetails = new ExamDetailsViewModel();

            examDetails.Id = examDetailsDto.Id;
            examDetails.ExamId = examDetailsDto.ExamId;
            examDetails.ExamType = examDetailsDto.ExamType;
            examDetails.NoOfTests = examDetailsDto.NoOfTests;
            examDetails.Description = examDetailsDto.Description;
            examDetails.PassingMarks = examDetailsDto.PassingMarks;
            examDetails.TotalMarks = examDetailsDto.TotalMarks;
            examDetails.NoOfQuestions = examDetailsDto.NoOfQuestions;
            examDetails.Date = examDetailsDto.Date;
            examDetails.ModifiedBy = Convert.ToInt32(Session["UserId"]);

            return View(examDetails);
        }

        [HttpPost]
        public ActionResult EditExamDetails(ExamDetailsViewModel examDetails)
        {
            ExamBal examBal = new ExamBal();
            ExamDetailsDto examDetailsDto = new ExamDetailsDto();

            examDetailsDto.Id = examDetails.Id;
            examDetailsDto.ExamId = examDetails.ExamId;
            examDetailsDto.ExamType = examDetails.ExamType;
            examDetailsDto.NoOfTests = examDetails.NoOfTests;
            examDetailsDto.Description = examDetails.Description;
            examDetailsDto.PassingMarks = examDetails.PassingMarks;
            examDetailsDto.TotalMarks = examDetails.TotalMarks;
            examDetailsDto.NoOfQuestions = examDetails.NoOfQuestions;
            examDetailsDto.Date = examDetails.Date;
            examDetailsDto.ModifiedBy = Convert.ToInt32(Session["UserId"]);

            examBal.UpdateExamDetailsBal(examDetailsDto);

            return View();
        }

        public ActionResult ExamDetails()
        {
            ExamBal examBal = new ExamBal();            
            List<ExamDetailsDto> examDetailsDtos = examBal.GetAllExamDetailsBal();
            List<ExamDetailsViewModel> examDetailList = new List<ExamDetailsViewModel>();

            foreach (var item in examDetailsDtos)
            {
                ExamDetailsViewModel examDetails = new ExamDetailsViewModel
                {
                    ExamId = item.ExamId,
                    ExamType = item.ExamType,
                    NoOfTests = item.NoOfTests,
                    Description=item.Description,
                    PassingMarks=item.PassingMarks,
                    TotalMarks=item.TotalMarks,
                    NoOfQuestions=item.NoOfQuestions,
                    Date=item.Date,
                    ModifiedBy=item.ModifiedBy
                };
                examDetailList.Add(examDetails);
            }
            return View(examDetailList);
        }

        public JsonResult DeleteExamDetails(int id)
        {
            ExamBal examBal = new ExamBal();
            examBal.DeleteExamDetailsBal(id);
            return Json(true, JsonRequestBehavior.AllowGet);
        }

        public ActionResult AssignExamToStudent()
        {
            return View();
        }
    }
}
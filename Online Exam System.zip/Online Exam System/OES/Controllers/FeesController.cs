﻿using BAL;
using DTO;
using OES.Models;
using System;
using System.Collections.Generic;
using System.Web.Mvc;

namespace OES.Controllers
{
    [Authorize(Roles = "Admin")]
    public class FeesController : Controller
    {
        // GET: Fees
        public ActionResult Index()
        {
            FeesBal feesBal = new FeesBal();
            List<FeesDto> feesDtos = feesBal.GetAllFeesBal();
            ExamBal examBal = new ExamBal();
            List<Fees> feesList = new List<Fees>();

            foreach (var item in feesDtos)
            {
                Fees fees = new Fees();

                fees.Id = item.Id;
                fees.ExamId = item.ExamId;
                fees.ExamTitle = examBal.GetExamByIdBal(item.ExamId).ExamTitle;
                fees.Date = item.Date;
                fees.Amount = item.Amount;
                fees.ModifiedBy = item.ModifiedBy;

                feesList.Add(fees);
            }
            return View(feesList);
        }

        [HttpGet]
        public ActionResult EnterFees()
        {
            ExamBal examBal = new ExamBal();
            IEnumerable<SelectListItem> examTitleList = examBal.GetExamTitleList();
            ViewBag.ExamTitleDropDown = examTitleList;

            FeesBal feesBal = new FeesBal();
            Fees fees = new Fees();
            fees.Id = feesBal.GetFeeId();
            return View(fees);
        }

        [HttpPost]
        public ActionResult AddFees(Fees fees)
        {
            FeesBal feesBal = new FeesBal();
            FeesDto feesDto = new FeesDto();

            feesDto.Id = fees.Id;
            feesDto.ExamId = fees.ExamId;
            feesDto.Date = DateTime.Now.ToShortDateString();
            feesDto.Amount = fees.Amount;
            feesDto.ModifiedBy = Convert.ToInt32(Session["UserId"]);

            feesBal.InsertFeesBal(feesDto);
            return RedirectToAction("Index", "Fees");
        }

        [HttpGet]
        public ActionResult EnterFeesToEdit(string id)
        {
            ExamBal examBal = new ExamBal();
            IEnumerable<SelectListItem> examTitleList = examBal.GetExamTitleList();
            ViewBag.ExamTitleDropDown = examTitleList;

            FeesBal feesBal = new FeesBal();
            FeesDto feesDto = feesBal.GetFeesByIdBal(id);
            Fees fees = new Fees();

            fees.Id = feesDto.Id;
            fees.ExamId = feesDto.ExamId;
            fees.Amount = feesDto.Amount;
            fees.ModifiedBy = feesDto.ModifiedBy;

            return View(fees);
        }

        [HttpPost]
        public ActionResult EditFees(Fees fees)
        {
            FeesBal feesBal = new FeesBal();
            FeesDto feesDto = new FeesDto();

            feesDto.Id = fees.Id;
            feesDto.ExamId = fees.ExamId;
            feesDto.Amount = fees.Amount;
            feesDto.ModifiedBy = Convert.ToInt32(Session["UserId"]);
            feesDto.Date = DateTime.Now.ToShortDateString();

            feesBal.UpdateFeesBal(feesDto);
            return RedirectToAction("Index", "Fees");
        }

        public JsonResult DeleteFees(string id)
        {
            FeesBal feesBal = new FeesBal();
            feesBal.DeleteFeesBal(id);
            return Json(true, JsonRequestBehavior.AllowGet);
        }
    }
}
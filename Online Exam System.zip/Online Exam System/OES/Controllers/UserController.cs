﻿using BAL;
using DTO;
using OES.Models;
using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web.Mvc;
using System.Web.Security;

namespace OES.Controllers
{
    [AllowAnonymous]
    public class UserController : Controller
    {
        // GET: UserDetails
        public ActionResult SignUp()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CreateUser(User user)
        {
            UserDto userDto = new UserDto();
            UserBal userBal = new UserBal();
            bool checkUserNameExists = userBal.CheckUserNameExists(user.UserName);
            if (checkUserNameExists == false)
            {
                userDto.UserName = user.UserName;
                userDto.Email = user.Email;
                userDto.MobileNo = user.MobileNo;
                using (MD5 md5Hash = MD5.Create())
                {
                    userDto.Password = GetMd5Hash(md5Hash, user.Password);
                }
                if (user.Role == "Teacher")
                {
                    userDto.RoleId = 1;
                }
                if (user.Role == "Student")
                {
                    userDto.RoleId = 2;
                }
                userBal.InsertUserBal(userDto);
                return RedirectToAction("Login", "User");
            }
            else
            {
                ViewBag.Message = "UserName Already Exists.";
                return View();
            }
        }
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ValidateUser([Bind(Include= "UserName, Password")]User user)
        {
            //if (!ModelState.IsValid)
            //{
                UserBal userBal = new UserBal();
                UserDto userDto = new UserDto();
                userDto.UserName = user.UserName;
                using (MD5 md5Hash = MD5.Create())
                {
                    userDto.Password = GetMd5Hash(md5Hash, user.Password);
                }
                bool userResult = userBal.ValidateUser(userDto.UserName, userDto.Password);
                int roleId = userBal.GetRoleByUserName(userDto.UserName);
                int userId = userBal.GetIdByName(userDto.UserName);
                Session["UserId"] = userId;
                if (userResult == true)
                {
                    FormsAuthentication.SetAuthCookie(user.UserName, false);
                    if (roleId == 1)
                    {
                        return RedirectToAction("Dashboard", "Admin");
                    }
                    if (roleId == 2)
                    {
                        return RedirectToAction("ChoosePaper", "Exam");
                    }
                }
            //}            
            return View("Login", user);
        }
        public ActionResult EnterEmail()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ValidateEmail(User user)
        {
            UserDto userDto = new UserDto();
            userDto.Email = user.Email;
            UserBal userBal = new UserBal();
            bool emailExists = userBal.GetAllUserBal().Any(x => x.Email == userDto.Email);
            if (emailExists == true)
            {
                SendOtpToEmail();
                Session["Email"] = user.Email;
                return RedirectToAction("EnterOtp");
            }
            else
            {
                ViewBag.Message = "Enter valid email";
                return View();
            }
        }

        public ActionResult EnterOtp()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ValidateOtp(int otp)
        {
            if (otp == 1234)
            {
                return RedirectToAction("ChangePassword");
            }
            ViewBag.Message = "Enter valid OTP";
            return View();
        }

        public ActionResult EnterPassword()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ChangePassword(User user)
        {
            UserDto userDto = new UserDto();
            UserBal userBal = new UserBal();
            userDto.Email = Session["Email"].ToString();
            userDto = userBal.GetAllUserBal().SingleOrDefault(x => x.Email == userDto.Email);
            using (MD5 md5Hash = MD5.Create())
            {
                userDto.Password = GetMd5Hash(md5Hash, user.Password);
            }
            userBal.UpdateUserBal(userDto);
            return RedirectToAction("Login", "User");
        }

        static string GetMd5Hash(MD5 md5Hash, string input)
        {

            // Convert the input string to a byte array and compute the hash.
            byte[] data = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(input));

            // Create a new Stringbuilder to collect the bytes
            // and create a string.
            StringBuilder sBuilder = new StringBuilder();

            // Loop through each byte of the hashed data 
            // and format each one as a hexadecimal string.
            for (int i = 0; i < data.Length; i++)
            {
                sBuilder.Append(data[i].ToString("x2"));
            }

            // Return the hexadecimal string.
            return sBuilder.ToString();
        }

        public new ActionResult Profile()
        {
            UserDto userDto = new UserDto();
            UserBal userBal = new UserBal();
            userDto.Id = Convert.ToInt32(Session["UserId"]);
            userDto = userBal.GetUserByIdBal(userDto.Id);
            User user = new User();
            user.Id = userDto.Id;
            user.UserName = userDto.UserName;
            user.MobileNo = userDto.MobileNo;
            user.Email = userDto.Email;
            return View(user);
        }

        [HttpPost]
        public ActionResult UpdateContactNo(User user)
        {
            UserBal userBal = new UserBal();
            UserDto userDto = new UserDto();
            userDto.Id = user.Id;
            userDto= userBal.GetUserByIdBal(userDto.Id);
            userDto.MobileNo = user.MobileNo;
            return RedirectToAction("Profile","User",user);
        }

        public ActionResult LogOut()
        {
            Session.Clear();
            Session.Abandon(); // it will clear the session at the end of request
            FormsAuthentication.SignOut();
            return RedirectToAction("Login", "User");
        }

        void SendOtpToEmail()
        {

        }
    }
}